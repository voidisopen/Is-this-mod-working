import { users, jarAnalyses, type User, type InsertUser, type JarAnalysis, type InsertJarAnalysis, type AnalysisError, type AnalysisSolution } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createJarAnalysis(analysis: InsertJarAnalysis): Promise<JarAnalysis>;
  getJarAnalysis(id: number): Promise<JarAnalysis | undefined>;
  getAllJarAnalyses(): Promise<JarAnalysis[]>;
  updateJarAnalysis(id: number, updates: Partial<InsertJarAnalysis>): Promise<JarAnalysis | undefined>;
  
  // Store original JAR file
  storeOriginalJar(analysisId: number, jarBuffer: Buffer): Promise<void>;
  getOriginalJar(analysisId: number): Promise<Buffer | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private jarAnalyses: Map<number, JarAnalysis>;
  private originalJars: Map<number, Buffer>;
  private currentUserId: number;
  private currentAnalysisId: number;

  constructor() {
    this.users = new Map();
    this.jarAnalyses = new Map();
    this.originalJars = new Map();
    this.currentUserId = 1;
    this.currentAnalysisId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createJarAnalysis(insertAnalysis: InsertJarAnalysis): Promise<JarAnalysis> {
    const id = this.currentAnalysisId++;
    const analysis: JarAnalysis = { 
      ...insertAnalysis,
      modName: insertAnalysis.modName ?? null,
      modVersion: insertAnalysis.modVersion ?? null,
      mcVersion: insertAnalysis.mcVersion ?? null,
      loader: insertAnalysis.loader ?? null,
      targetMcVersion: insertAnalysis.targetMcVersion ?? "1.21",
      targetLoader: insertAnalysis.targetLoader ?? "quilt",
      errors: (insertAnalysis.errors as AnalysisError[]) || [],
      solutions: (insertAnalysis.solutions as AnalysisSolution[]) || [],
      aiAnalysis: insertAnalysis.aiAnalysis ?? null,
      errorLog: insertAnalysis.errorLog ?? null,
      isFixed: insertAnalysis.isFixed ?? false,
      id, 
      createdAt: new Date() 
    };
    this.jarAnalyses.set(id, analysis);
    return analysis;
  }

  async getJarAnalysis(id: number): Promise<JarAnalysis | undefined> {
    return this.jarAnalyses.get(id);
  }

  async getAllJarAnalyses(): Promise<JarAnalysis[]> {
    return Array.from(this.jarAnalyses.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async updateJarAnalysis(id: number, updates: Partial<InsertJarAnalysis>): Promise<JarAnalysis | undefined> {
    const existing = this.jarAnalyses.get(id);
    if (!existing) return undefined;
    
    const updated: JarAnalysis = { 
      ...existing, 
      ...updates,
      errors: (updates.errors as AnalysisError[]) || existing.errors,
      solutions: (updates.solutions as AnalysisSolution[]) || existing.solutions
    };
    this.jarAnalyses.set(id, updated);
    return updated;
  }

  async storeOriginalJar(analysisId: number, jarBuffer: Buffer): Promise<void> {
    this.originalJars.set(analysisId, jarBuffer);
  }

  async getOriginalJar(analysisId: number): Promise<Buffer | undefined> {
    return this.originalJars.get(analysisId);
  }
}

export const storage = new MemStorage();
