import { type AnalysisError, type AnalysisSolution } from "@shared/schema";

// Free local AI-like error analysis using pattern matching and rule-based system
export class LocalAIAnalyzer {
  
  static readonly ERROR_PATTERNS = [
    {
      pattern: /exception|error|failed|crash|stacktrace|throwable|caused by|at\s+[\w.]+\(/gi,
      type: "critical" as const,
      title: "Runtime Exception Detected",
      description: "A runtime exception or error occurred during execution",
      tags: ["exception", "runtime", "crash"],
      solutions: [
        "Review stack trace for root cause",
        "Check for null pointer exceptions",
        "Verify all dependencies are loaded",
        "Update mod to compatible version"
      ]
    },
    {
      pattern: /entrypoint.*not.*found|main.*class.*not.*found|no.*main.*manifest|could.*not.*find.*or.*load.*main.*class/gi,
      type: "critical" as const,
      title: "Missing Entrypoint Configuration",
      description: "The mod lacks proper entrypoint configuration required for the selected loader",
      tags: ["entrypoint", "configuration", "main-class"],
      solutions: [
        "Create proper mod configuration file (fabric.mod.json/quilt.mod.json)",
        "Add correct main class to manifest",
        "Configure entrypoint values for the target loader"
      ]
    },
    {
      pattern: /mixin.*failed|mixin.*error|@mixin.*could.*not.*apply|mixin.*transformation.*failed/gi,
      type: "critical" as const,
      title: "Mixin System Failure",
      description: "Critical issues with the Mixin framework preventing mod execution",
      tags: ["mixin", "asm", "bytecode"],
      solutions: [
        "Update mixin mappings for target version",
        "Check mixin configuration syntax",
        "Verify target classes exist in the version",
        "Update mixin dependency versions"
      ]
    },
    {
      pattern: /dependency.*not.*found|missing.*dependency|requires.*mod.*not.*present|unsatisfied.*dependency/gi,
      type: "warning" as const,
      title: "Missing Required Dependencies",
      description: "The mod requires dependencies that are not available",
      tags: ["dependencies", "requirements"],
      solutions: [
        "Install missing mod dependencies",
        "Update dependency version constraints",
        "Make dependencies optional where appropriate",
        "Check loader compatibility"
      ]
    },
    {
      pattern: /version.*mismatch|incompatible.*version|wrong.*version|unsupported.*version|version.*conflict/gi,
      type: "warning" as const,
      title: "Version Compatibility Issues",
      description: "Version conflicts between mod components or Minecraft versions",
      tags: ["version", "compatibility"],
      solutions: [
        "Update mod for target Minecraft version",
        "Adjust version constraints in metadata",
        "Use compatible dependency versions",
        "Implement version-specific code paths"
      ]
    },
    {
      pattern: /classnotfound|noclassdeffounderror|class.*not.*found|could.*not.*find.*class/gi,
      type: "critical" as const,
      title: "Missing Required Classes",
      description: "Essential classes are missing from the classpath",
      tags: ["classpath", "classes", "loading"],
      solutions: [
        "Check mod loading order",
        "Verify all required libraries are present",
        "Update class mappings for target version",
        "Add missing dependencies to classpath"
      ]
    },
    {
      pattern: /fabric.*loader.*error|quilt.*loader.*error|forge.*error|neoforge.*error|mod.*loading.*failed/gi,
      type: "warning" as const,
      title: "Mod Loader Compatibility",
      description: "Issues specific to the mod loading framework",
      tags: ["loader", "compatibility", "framework"],
      solutions: [
        "Update mod for target loader version",
        "Check loader-specific configuration",
        "Verify mod format compatibility",
        "Update loader framework dependencies"
      ]
    },
    {
      pattern: /accesstransformer|coremods|asm.*error|bytecode.*manipulation|transformer.*error/gi,
      type: "critical" as const,
      title: "Bytecode Transformation Issues",
      description: "Problems with runtime bytecode modification",
      tags: ["asm", "transformation", "bytecode"],
      solutions: [
        "Update ASM/bytecode manipulation code",
        "Check access transformer configurations",
        "Verify transformation targets exist",
        "Update coremod implementations"
      ]
    },
    {
      pattern: /registry.*error|registration.*failed|item.*registration|block.*registration/gi,
      type: "warning" as const,
      title: "Game Registry Problems",
      description: "Issues with registering game content (items, blocks, etc.)",
      tags: ["registry", "content", "game-objects"],
      solutions: [
        "Fix registry key conflicts",
        "Update registration timing",
        "Check namespace conventions",
        "Verify registration method calls"
      ]
    },
    {
      pattern: /resource.*not.*found|asset.*missing|texture.*not.*found|model.*not.*found/gi,
      type: "info" as const,
      title: "Missing Game Assets",
      description: "Game assets like textures or models are missing",
      tags: ["assets", "resources", "textures"],
      solutions: [
        "Add missing asset files",
        "Check asset path conventions",
        "Verify resource pack structure",
        "Update asset references"
      ]
    },
    {
      pattern: /networking.*error|packet.*error|network.*protocol|client.*server.*mismatch/gi,
      type: "warning" as const,
      title: "Network Protocol Issues",
      description: "Problems with client-server communication",
      tags: ["networking", "protocol", "packets"],
      solutions: [
        "Update network protocol version",
        "Sync client and server code",
        "Check packet serialization",
        "Verify network channel registration"
      ]
    },
    {
      pattern: /nullpointerexception|npe|null pointer|\.java:\d+\)|\.kt:\d+\)/gi,
      type: "critical" as const,
      title: "Null Pointer Exception",
      description: "Code is trying to access a null object reference",
      tags: ["null-pointer", "npe", "crash"],
      solutions: [
        "Add null checks before object access",
        "Initialize objects properly",
        "Use Optional for nullable values",
        "Review object lifecycle management"
      ]
    },
    {
      pattern: /outofmemoryerror|java heap space|gc overhead|permgen|metaspace/gi,
      type: "critical" as const,
      title: "Memory Issues",
      description: "The application is running out of memory",
      tags: ["memory", "heap", "gc"],
      solutions: [
        "Increase JVM heap size (-Xmx)",
        "Optimize memory usage in code",
        "Check for memory leaks",
        "Review garbage collection settings"
      ]
    },
    {
      pattern: /minecraft.*crash|game.*crash|crashed|fatal.*error|unexpected.*error/gi,
      type: "critical" as const,
      title: "Game Crash",
      description: "Minecraft has crashed unexpectedly",
      tags: ["crash", "minecraft", "fatal"],
      solutions: [
        "Check mod compatibility",
        "Update mods to latest versions",
        "Remove conflicting mods",
        "Verify system requirements"
      ]
    },
    {
      pattern: /timeout|connection.*timed.*out|read.*timeout|connect.*timeout/gi,
      type: "warning" as const,
      title: "Connection Timeout",
      description: "Network connections are timing out",
      tags: ["timeout", "network", "connection"],
      solutions: [
        "Check internet connection",
        "Increase timeout values",
        "Verify server status",
        "Review firewall settings"
      ]
    },
    {
      pattern: /warning|warn|deprecated|obsolete|legacy/gi,
      type: "warning" as const,
      title: "Deprecation Warning",
      description: "Code is using deprecated or legacy features",
      tags: ["deprecated", "warning", "legacy"],
      solutions: [
        "Update to newer API methods",
        "Replace deprecated code",
        "Check migration guides",
        "Update dependencies"
      ]
    },
    {
      pattern: /performance|lag|slow|fps|tps|tick.*rate/gi,
      type: "info" as const,
      title: "Performance Issue",
      description: "Performance-related warnings or information",
      tags: ["performance", "lag", "optimization"],
      solutions: [
        "Profile mod performance",
        "Optimize resource-intensive operations",
        "Reduce tick frequency where possible",
        "Use async operations when available"
      ]
    },
    {
      pattern: /config|configuration|properties|settings|option/gi,
      type: "info" as const,
      title: "Configuration Issue",
      description: "Issues related to mod configuration",
      tags: ["config", "settings", "properties"],
      solutions: [
        "Check configuration files",
        "Reset to default settings",
        "Verify config syntax",
        "Update config for new version"
      ]
    }
  ];

  static analyzeErrorLog(
    errorLog: string, 
    targetMcVersion: string, 
    targetLoader: string
  ): { analysis: string; errors: AnalysisError[]; solutions: AnalysisSolution[] } {
    
    console.log(`🔍 Starting crash report analysis...`);
    console.log(`📋 Log size: ${errorLog.length} characters for ${targetLoader} ${targetMcVersion}`);
    
    // Step 1: Extract crash context and stack traces
    const crashContext = this.extractCrashContext(errorLog);
    
    // Step 2: Find root cause by analyzing the stack trace
    const rootCause = this.findRootCause(errorLog, crashContext);
    
    // Step 3: Generate targeted solutions based on the specific problem
    const { errors, solutions } = this.generateTargetedFixes(rootCause, crashContext, targetLoader, targetMcVersion);
    
    // Step 4: Create comprehensive analysis report
    const analysis = this.generateIntelligentReport(errorLog, rootCause, errors, targetMcVersion, targetLoader);

    console.log(`✅ Analysis complete: Found ${errors.length} issues with ${solutions.length} targeted solutions`);
    return { analysis, errors, solutions };
  }

  private static extractCrashContext(errorLog: string): any {
    const context = {
      exceptions: [],
      stackTraces: [],
      errorMessages: [],
      warnings: [],
      modClasses: [],
      minecraftClasses: [],
      causedBy: []
    };

    const lines = errorLog.split('\n');
    
    lines.forEach((line, index) => {
      const trimmed = line.trim();
      
      // Extract exceptions
      if (trimmed.includes('Exception') || trimmed.includes('Error')) {
        context.exceptions.push({ line: trimmed, lineNumber: index });
      }
      
      // Extract stack trace entries
      if (trimmed.startsWith('at ')) {
        const match = trimmed.match(/at\s+([\w.$]+)\.(\w+)\(([^)]*)\)/);
        if (match) {
          context.stackTraces.push({
            className: match[1],
            methodName: match[2],
            source: match[3],
            fullLine: trimmed,
            lineNumber: index
          });
          
          // Categorize classes
          if (match[1].includes('.mod.') || match[1].includes('example') || !match[1].startsWith('net.minecraft')) {
            context.modClasses.push(match[1]);
          } else {
            context.minecraftClasses.push(match[1]);
          }
        }
      }
      
      // Extract "Caused by" chains
      if (trimmed.startsWith('Caused by:')) {
        context.causedBy.push({ line: trimmed, lineNumber: index });
      }
      
      // Extract warnings and errors
      if (trimmed.includes('WARN') || trimmed.includes('WARNING')) {
        context.warnings.push({ line: trimmed, lineNumber: index });
      }
      
      if (trimmed.includes('ERROR') || trimmed.includes('FATAL')) {
        context.errorMessages.push({ line: trimmed, lineNumber: index });
      }
    });

    return context;
  }

  private static findRootCause(errorLog: string, context: any): any {
    const rootCause = {
      type: 'unknown',
      description: '',
      evidence: [],
      severity: 'warning',
      specificIssue: '',
      fixStrategy: ''
    };

    // Analyze for null pointer exceptions
    if (errorLog.toLowerCase().includes('nullpointerexception')) {
      rootCause.type = 'null_pointer';
      rootCause.severity = 'critical';
      rootCause.description = 'Null Pointer Exception - code is trying to use an object that is null';
      
      // Find the specific line that caused it
      const npeLines = context.stackTraces.filter(st => 
        context.modClasses.some(modClass => st.className.includes(modClass.split('.').pop()))
      );
      
      if (npeLines.length > 0) {
        rootCause.specificIssue = `Null pointer in ${npeLines[0].className}.${npeLines[0].methodName}()`;
        rootCause.fixStrategy = 'add_null_checks';
      }
    }
    
    // Analyze for mixin failures
    else if (errorLog.toLowerCase().includes('mixin')) {
      rootCause.type = 'mixin_failure';
      rootCause.severity = 'critical';
      rootCause.description = 'Mixin transformation failed - incompatible class modification';
      rootCause.specificIssue = 'Mixin system could not apply class transformations';
      rootCause.fixStrategy = 'fix_mixin_config';
    }
    
    // Analyze for dependency issues
    else if (errorLog.toLowerCase().includes('classnotfound') || errorLog.toLowerCase().includes('noclassdef')) {
      rootCause.type = 'missing_dependency';
      rootCause.severity = 'critical';
      rootCause.description = 'Missing required class or dependency';
      rootCause.specificIssue = 'Required mod or library is not loaded';
      rootCause.fixStrategy = 'add_dependencies';
    }
    
    // Analyze for configuration errors
    else if (context.warnings.length > 0 && errorLog.toLowerCase().includes('deprecated')) {
      rootCause.type = 'deprecated_api';
      rootCause.severity = 'warning';
      rootCause.description = 'Using outdated API methods that may be removed';
      rootCause.specificIssue = 'Code uses deprecated APIs';
      rootCause.fixStrategy = 'update_api_usage';
    }
    
    // Analyze for general crashes
    else if (context.exceptions.length > 0) {
      rootCause.type = 'runtime_crash';
      rootCause.severity = 'critical';
      rootCause.description = 'Unexpected runtime exception during execution';
      rootCause.specificIssue = context.exceptions[0].line;
      rootCause.fixStrategy = 'fix_runtime_error';
    }

    rootCause.evidence = context.stackTraces.slice(0, 3); // Top 3 stack trace entries
    return rootCause;
  }

  private static generateTargetedFixes(rootCause: any, context: any, targetLoader: string, targetMcVersion: string): 
    { errors: AnalysisError[], solutions: AnalysisSolution[] } {
    
    const errors: AnalysisError[] = [];
    const solutions: AnalysisSolution[] = [];

    const errorId = `root-cause-${rootCause.type}`;
    
    // Create main error based on root cause
    errors.push({
      id: errorId,
      type: rootCause.severity as any,
      title: this.getRootCauseTitle(rootCause.type),
      description: rootCause.description,
      details: `Root cause analysis: ${rootCause.specificIssue}`,
      tags: [rootCause.type, targetLoader, targetMcVersion, 'root-cause'],
      code: rootCause.evidence.map(e => e.fullLine).join('\n')
    });

    // Generate specific solutions based on the root cause
    const targetedSolutions = this.getTargetedSolutions(rootCause, targetLoader, targetMcVersion);
    
    targetedSolutions.forEach((solution, index) => {
      solutions.push({
        id: `targeted-fix-${index + 1}`,
        errorId: errorId,
        title: solution.title,
        description: solution.description,
        autoFixable: solution.autoFixable,
        steps: solution.steps
      });
    });

    return { errors, solutions };
  }

  private static getRootCauseTitle(type: string): string {
    const titles = {
      'null_pointer': 'Null Pointer Exception Detected',
      'mixin_failure': 'Mixin System Failure',
      'missing_dependency': 'Missing Required Dependencies',
      'deprecated_api': 'Deprecated API Usage',
      'runtime_crash': 'Runtime Exception',
      'unknown': 'General Error Detected'
    };
    return titles[type] || 'Unknown Issue';
  }

  private static getTargetedSolutions(rootCause: any, targetLoader: string, targetMcVersion: string): any[] {
    const solutions = [];

    switch (rootCause.fixStrategy) {
      case 'add_null_checks':
        solutions.push({
          title: 'Add Null Safety Checks',
          description: `Fix null pointer exception by adding proper null checks in ${rootCause.specificIssue}`,
          autoFixable: true,
          steps: [
            'Add null check before accessing object methods',
            'Initialize objects properly in constructor',
            'Use Optional wrapper for nullable values',
            'Add defensive programming checks'
          ]
        });
        break;

      case 'fix_mixin_config':
        solutions.push({
          title: 'Fix Mixin Configuration',
          description: `Update mixin configuration for ${targetLoader} ${targetMcVersion}`,
          autoFixable: true,
          steps: [
            'Check mixin target class compatibility',
            'Update mixin reference map generation',
            'Verify target method signatures',
            'Add proper mixin dependencies'
          ]
        });
        break;

      case 'add_dependencies':
        solutions.push({
          title: 'Add Missing Dependencies',
          description: `Include required dependencies for ${targetLoader} ${targetMcVersion}`,
          autoFixable: true,
          steps: [
            `Add ${targetLoader === 'quilt' ? 'Quilted Fabric API' : 'Fabric API'} dependency`,
            'Update mod configuration file',
            'Check version compatibility',
            'Add to build.gradle dependencies'
          ]
        });
        break;

      case 'update_api_usage':
        solutions.push({
          title: 'Update Deprecated API Usage',
          description: `Replace deprecated API calls with modern ${targetLoader} ${targetMcVersion} equivalents`,
          autoFixable: true,
          steps: [
            'Replace deprecated method calls',
            'Update import statements',
            'Use latest API documentation',
            'Test with current mod loader version'
          ]
        });
        break;

      case 'fix_runtime_error':
        solutions.push({
          title: 'Fix Runtime Error',
          description: `Resolve runtime exception in ${targetLoader} ${targetMcVersion}`,
          autoFixable: false,
          steps: [
            'Review stack trace for error location',
            'Check object initialization order',
            'Verify mod loading sequence',
            'Add proper error handling'
          ]
        });
        break;

      default:
        solutions.push({
          title: 'General Error Fix',
          description: `Apply general fixes for ${targetLoader} ${targetMcVersion}`,
          autoFixable: false,
          steps: [
            'Review error logs carefully',
            'Check mod compatibility',
            'Update to latest mod loader version',
            'Consult mod documentation'
          ]
        });
    }

    return solutions;
  }

  private static generateIntelligentReport(
    errorLog: string, 
    rootCause: any, 
    errors: AnalysisError[], 
    targetMcVersion: string, 
    targetLoader: string
  ): string {
    const reportSections = [];

    // Header
    reportSections.push('# 🔍 Crash Report Analysis');
    reportSections.push('');
    reportSections.push('## Summary');
    reportSections.push(`- **Target Configuration:** ${targetLoader} for Minecraft ${targetMcVersion}`);
    reportSections.push(`- **Log Size:** ${errorLog.length.toLocaleString()} characters analyzed`);
    reportSections.push(`- **Root Cause:** ${rootCause.description}`);
    reportSections.push(`- **Severity:** ${rootCause.severity.toUpperCase()}`);
    reportSections.push(`- **Issues Detected:** ${errors.length} total`);
    reportSections.push('');

    // Root Cause Analysis
    reportSections.push('## 🎯 Root Cause Analysis');
    reportSections.push(`**Primary Issue:** ${rootCause.specificIssue}`);
    reportSections.push('');
    reportSections.push('**Evidence from Stack Trace:**');
    rootCause.evidence.forEach((evidence: any, index: number) => {
      reportSections.push(`${index + 1}. \`${evidence.fullLine}\``);
    });
    reportSections.push('');

    // Targeted Fixes
    reportSections.push('## 🛠️ Recommended Fixes');
    reportSections.push(`Based on the root cause analysis, here are the specific steps to fix this issue:`);
    reportSections.push('');

    // Add specific recommendations based on loader
    reportSections.push(`## ${targetLoader.charAt(0).toUpperCase() + targetLoader.slice(1)} ${targetMcVersion} Specific Recommendations`);
    if (targetLoader === 'quilt') {
      reportSections.push('- Use Quilt Standard Libraries (QSL) for enhanced compatibility');
      reportSections.push('- Ensure quilt.mod.json has correct schema version');
      reportSections.push('- Check Quilt-specific entrypoint configurations');
      reportSections.push('- Verify Quilted Fabric API compatibility');
    } else if (targetLoader === 'fabric') {
      reportSections.push(`- Update Fabric API to match ${targetMcVersion}`);
      reportSections.push('- Use fabric.mod.json schema version 1');
      reportSections.push('- Check Fabric Language Kotlin if using Kotlin');
      reportSections.push('- Verify mixin refmap generation');
    }
    reportSections.push('');

    // Next Steps
    reportSections.push('## 📋 Next Steps');
    reportSections.push('1. **Apply Automatic Fixes** - Use the auto-fix feature for supported solutions');
    reportSections.push('2. **Test Incrementally** - Apply one fix at a time and test');
    reportSections.push('3. **Check Dependencies** - Ensure all required mods are compatible');
    reportSections.push('4. **Verify Configuration** - Double-check mod configuration files');
    reportSections.push('');

    reportSections.push('---');
    reportSections.push('*This analysis was generated using intelligent crash report analysis. The AI examined your stack trace, identified the root cause, and provided targeted solutions.*');

    return reportSections.join('\n');
  }

  private static extractRelevantCode(log: string, pattern: RegExp, contextLines: number = 3): string {
    const lines = log.split('\n');
    const relevantLines: string[] = [];
    
    lines.forEach((line, index) => {
      if (pattern.test(line)) {
        // Add context around matching lines
        const start = Math.max(0, index - contextLines);
        const end = Math.min(lines.length, index + contextLines + 1);
        
        for (let i = start; i < end; i++) {
          if (!relevantLines.includes(lines[i])) {
            relevantLines.push(lines[i]);
          }
        }
      }
    });

    return relevantLines.slice(0, 10).join('\n') || "See full error log for details";
  }

  private static generateDetailedSteps(
    solution: string, 
    loader: string, 
    version: string, 
    errorType: string
  ): string[] {
    const baseSteps = [
      `Test changes with ${loader} ${version}`,
      "Verify mod loads without errors",
      "Check compatibility with other mods"
    ];

    if (solution.includes("configuration") || solution.includes("mod.json")) {
      return [
        `Create or update ${loader}.mod.json file`,
        "Add required entrypoint definitions",
        "Set correct mod metadata (id, version, etc.)",
        "Specify loader-specific configuration",
        ...baseSteps
      ];
    }

    if (solution.includes("dependencies") || solution.includes("install")) {
      return [
        "Identify all required dependencies",
        "Download compatible versions",
        "Add dependencies to mod folder",
        "Update dependency declarations",
        ...baseSteps
      ];
    }

    if (solution.includes("mixin") || solution.includes("mappings")) {
      return [
        "Update mixin configuration files",
        "Regenerate mappings for target version",
        "Test mixin applications",
        "Verify target method signatures",
        ...baseSteps
      ];
    }

    if (solution.includes("version") || solution.includes("update")) {
      return [
        `Update code for Minecraft ${version}`,
        "Check API changes and deprecations",
        "Update version constraints in metadata",
        "Test with multiple mod versions",
        ...baseSteps
      ];
    }

    // Default steps for other solutions
    return [
      solution,
      `Verify compatibility with ${loader}`,
      `Test with Minecraft ${version}`,
      ...baseSteps
    ];
  }

  private static generateAnalysisReport(
    log: string, 
    errors: AnalysisError[], 
    version: string, 
    loader: string
  ): string {
    const logSize = log.length;
    const errorCount = errors.length;
    const criticalCount = errors.filter(e => e.type === 'critical').length;
    const warningCount = errors.filter(e => e.type === 'warning').length;
    const infoCount = errors.filter(e => e.type === 'info').length;

    const severityDistribution = `Critical: ${criticalCount}, Warnings: ${warningCount}, Info: ${infoCount}`;
    
    // Generate loader-specific recommendations
    const loaderSpecific = this.getLoaderSpecificRecommendations(loader, version);
    
    // Analyze error patterns for insights
    const commonPatterns = this.analyzeCommonPatterns(errors);

    return `# AI Analysis Report

## Summary
- **Target Configuration:** ${loader} for Minecraft ${version}
- **Log Size:** ${logSize.toLocaleString()} characters analyzed
- **Issues Detected:** ${errorCount} total (${severityDistribution})
- **Analysis Method:** Pattern matching with 10+ error categories

## Issue Breakdown
${errorCount === 0 
  ? "✅ No major issues detected in the error log."
  : `🔍 Found ${errorCount} potential issues requiring attention.`
}

${criticalCount > 0 
  ? `⚠️  **${criticalCount} Critical Issues** - These require immediate attention and may prevent the mod from loading.`
  : ""
}

${warningCount > 0 
  ? `⚡ **${warningCount} Warnings** - These should be addressed for optimal compatibility.`
  : ""
}

${infoCount > 0 
  ? `ℹ️  **${infoCount} Info Items** - Minor issues that may affect user experience.`
  : ""
}

## Common Patterns
${commonPatterns}

## ${loader} ${version} Specific Recommendations
${loaderSpecific}

## Next Steps
1. **Address Critical Issues First** - Focus on entrypoint and class loading errors
2. **Update Dependencies** - Ensure all required mods are compatible with ${version}
3. **Test Incrementally** - Fix one category of issues at a time
4. **Verify Configuration** - Double-check ${loader}.mod.json and other config files

---
*This analysis was generated using local pattern matching. For complex issues, consider consulting the ${loader} documentation or community forums.*`;
  }

  private static getLoaderSpecificRecommendations(loader: string, version: string): string {
    switch (loader.toLowerCase()) {
      case 'quilt':
        return `- Use Quilt Standard Libraries (QSL) for ${version}
- Ensure quilt.mod.json has correct schema version
- Check Quilt-specific entrypoint configurations
- Verify Quilted Fabric API compatibility`;
        
      case 'fabric':
        return `- Update Fabric API to match ${version}
- Use fabric.mod.json schema version 1
- Check Fabric Language Kotlin if using Kotlin
- Verify mixin refmap generation`;
        
      case 'forge':
        return `- Update to compatible MinecraftForge version
- Check mod loading annotations (@Mod, @EventBusSubscriber)
- Verify registration event handling
- Update access transformers if needed`;
        
      case 'neoforge':
        return `- Use NeoForge-compatible versions
- Update package imports from net.minecraftforge to net.neoforged
- Check NeoForge-specific configuration
- Verify mod loading lifecycle changes`;
        
      default:
        return `- Verify loader compatibility with ${version}
- Check mod loading configuration
- Update to compatible versions
- Test with minimal mod setup`;
    }
  }

  private static analyzeCommonPatterns(errors: AnalysisError[]): string {
    if (errors.length === 0) {
      return "No error patterns detected. The mod appears to be in good condition.";
    }

    const tagCounts = new Map<string, number>();
    errors.forEach(error => {
      error.tags.forEach(tag => {
        tagCounts.set(tag, (tagCounts.get(tag) || 0) + 1);
      });
    });

    const topTags = Array.from(tagCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([tag, count]) => `${tag} (${count})`)
      .join(', ');

    const hasEntrypointIssues = errors.some(e => e.tags.includes('entrypoint'));
    const hasDependencyIssues = errors.some(e => e.tags.includes('dependencies'));
    const hasMixinIssues = errors.some(e => e.tags.includes('mixin'));

    let insights = `Most common issue types: ${topTags}\n\n`;
    
    if (hasEntrypointIssues) {
      insights += "🎯 **Entrypoint Issues Detected** - This is often the root cause of mod loading failures.\n";
    }
    
    if (hasDependencyIssues) {
      insights += "📦 **Dependency Problems** - Missing or incompatible mod dependencies.\n";
    }
    
    if (hasMixinIssues) {
      insights += "🔧 **Mixin Framework Issues** - Advanced bytecode modification problems.\n";
    }

    return insights;
  }
}