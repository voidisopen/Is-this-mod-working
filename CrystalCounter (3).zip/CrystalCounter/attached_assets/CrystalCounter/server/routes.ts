import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertJarAnalysisSchema, type AnalysisError, type AnalysisSolution, type JarAnalysis } from "@shared/schema";
import { LocalAIAnalyzer } from "./ai-analyzer";
import multer from "multer";
import JSZip from "jszip";

interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // AI Error Log Analysis - MUST be first to avoid Vite interference
  app.post("/api/analyze-errorlog", async (req, res) => {
    console.log("AI Error Log Analysis route hit!");
    console.log("Request body:", req.body);
    
    try {
      const { errorLog, targetMcVersion, targetLoader } = req.body;
      
      if (!errorLog || !targetMcVersion || !targetLoader) {
        console.log("Missing fields:", { errorLog: !!errorLog, targetMcVersion, targetLoader });
        return res.status(400).json({ 
          message: "Missing required fields: errorLog, targetMcVersion, targetLoader" 
        });
      }

      if (errorLog.length > 10000000) { // 10MB limit
        return res.status(400).json({ 
          message: "Error log too large. Maximum size is 10 million characters." 
        });
      }

      console.log(`Analyzing error log for ${targetLoader} ${targetMcVersion}...`);
      console.log(`Error log length: ${errorLog.length} characters`);
      
      // Use local AI analyzer
      const analysisResult = LocalAIAnalyzer.analyzeErrorLog(errorLog, targetMcVersion, targetLoader);
      
      console.log("Analysis result:", {
        errorsFound: analysisResult.errors.length,
        solutionsFound: analysisResult.solutions.length
      });
      
      // Create analysis record
      const analysis = await storage.createJarAnalysis({
        fileName: "AI Error Log Analysis",
        fileSize: errorLog.length,
        modName: "Error Log Analysis",
        modVersion: "Unknown",
        mcVersion: "Various",
        loader: "unknown",
        targetMcVersion: targetMcVersion,
        targetLoader: targetLoader,
        errors: analysisResult.errors,
        solutions: analysisResult.solutions,
        aiAnalysis: analysisResult.analysis,
        errorLog: errorLog,
        isFixed: false
      });

      console.log(`AI analysis complete. Found ${analysisResult.errors.length} issues, ${analysisResult.solutions.length} solutions`);
      
      res.json(analysis);
    } catch (error) {
      console.error("AI analysis error:", error);
      res.status(500).json({ message: "Failed to analyze error log", error: error.message });
    }
  });

  // Get all analyses
  app.get("/api/analyses", async (req, res) => {
    try {
      const analyses = await storage.getAllJarAnalyses();
      res.json(analyses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch analyses" });
    }
  });

  // Get specific analysis
  app.get("/api/analyses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analysis = await storage.getJarAnalysis(id);
      
      if (!analysis) {
        return res.status(404).json({ message: "Analysis not found" });
      }
      
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch analysis" });
    }
  });

  // Enhanced JAR Analysis with AI crash report integration
  app.post("/api/analyze", upload.single("jarFile"), async (req: MulterRequest, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const jarBuffer = req.file.buffer;
      const fileName = req.file.originalname;
      const fileSize = req.file.size;
      const { targetMcVersion = "1.21", targetLoader = "quilt", crashReport = "" } = req.body;

      console.log(`🔍 Analyzing JAR file: ${fileName} (${fileSize} bytes)`);
      console.log(`🎯 Target: ${targetLoader} ${targetMcVersion}`);
      if (crashReport) console.log(`📋 Crash report provided: ${crashReport.length} characters`);
      
      // Step 1: Basic JAR file analysis
      const analysisResult = await analyzeJarFile(jarBuffer, fileName, fileSize, targetMcVersion, targetLoader);
      
      // Step 2: AI-powered crash report analysis (if provided)
      if (crashReport && crashReport.trim().length > 0) {
        console.log("🤖 Running AI crash report analysis...");
        const aiResult = LocalAIAnalyzer.analyzeErrorLog(crashReport, targetMcVersion, targetLoader);
        
        // Merge AI findings with basic analysis
        analysisResult.errors = [...analysisResult.errors, ...aiResult.errors];
        analysisResult.solutions = [...analysisResult.solutions, ...aiResult.solutions];
        analysisResult.aiAnalysis = aiResult.analysis;
        analysisResult.errorLog = crashReport;
        
        console.log(`🎯 AI analysis found ${aiResult.errors.length} additional issues from crash report`);
      }
      
      console.log(`✅ Complete analysis finished. Found ${analysisResult.errors.length} total issues, ${analysisResult.solutions.length} solutions`);
      
      // Store analysis in memory
      const analysis = await storage.createJarAnalysis(analysisResult);
      
      // Store the original JAR file for later fixing
      await storage.storeOriginalJar(analysis.id, jarBuffer);
      
      res.json(analysis);
    } catch (error) {
      console.error("Analysis error:", error);
      res.status(500).json({ message: "Failed to analyze JAR file" });
    }
  });



  // Apply auto-fix to JAR file
  app.post("/api/analyses/:id/fix", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { solutionId } = req.body;
      
      const analysis = await storage.getJarAnalysis(id);
      if (!analysis) {
        return res.status(404).json({ message: "Analysis not found" });
      }

      // Find the solution
      const solution = analysis.solutions?.find(s => s.id === solutionId);
      if (!solution || !solution.autoFixable) {
        return res.status(400).json({ message: "Solution not auto-fixable" });
      }

      // Apply the fix (simplified implementation)
      const updatedAnalysis = await storage.updateJarAnalysis(id, {
        isFixed: true,
        errors: analysis.errors?.filter(e => e.id !== solution.errorId) || []
      });

      res.json(updatedAnalysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to apply fix" });
    }
  });

  // Download fixed JAR file
  app.get("/api/analyses/:id/download", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      console.log(`🔽 Download request for analysis ID: ${id}`);
      
      const analysis = await storage.getJarAnalysis(id);
      
      if (!analysis) {
        console.log(`❌ Analysis ${id} not found in storage`);
        // List all available analyses for debugging
        const allAnalyses = await storage.getAllJarAnalyses();
        console.log(`📋 Available analyses: ${allAnalyses.map(a => a.id).join(', ')}`);
        return res.status(404).json({ 
          message: "Analysis not found",
          availableIds: allAnalyses.map(a => a.id),
          requestedId: id
        });
      }

      console.log(`✅ Found analysis: ${analysis.fileName}`);

      // Check if we have an original JAR file to fix
      const originalJar = await storage.getOriginalJar(analysis.id);
      
      let fixedJarBuffer: Buffer;
      let fixedFileName: string;
      
      if (!originalJar) {
        console.log(`⚠️  No original JAR found for analysis ${id}, generating template JAR`);
        // For error log analyses without JAR files, create a template
        fixedJarBuffer = await generateTemplateJar(analysis);
        fixedFileName = `${analysis.modName?.replace(/\s+/g, '_') || 'AI_Fixed_Mod'}_TEMPLATE.jar`;
      } else {
        // Generate fixed JAR file from original
        console.log(`🔧 Generating fixed JAR from original...`);
        fixedJarBuffer = await generateFixedJar(analysis);
        fixedFileName = analysis.fileName.replace('.jar', '_FIXED.jar');
      }
      
      res.setHeader('Content-Type', 'application/java-archive');
      res.setHeader('Content-Disposition', `attachment; filename="${fixedFileName}"`);
      res.setHeader('Content-Length', fixedJarBuffer.length);
      
      console.log(`📦 Sending fixed JAR: ${fixedFileName} (${fixedJarBuffer.length} bytes)`);
      res.send(fixedJarBuffer);
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ message: "Failed to generate fixed JAR", error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function generateTemplateJar(analysis: JarAnalysis): Promise<Buffer> {
  try {
    console.log(`🏗️  Creating template JAR for ${analysis.modName}`);
    const JSZip = (await import('jszip')).default;
    const zip = new JSZip();
    
    // Extract mod name from analysis
    const modId = (analysis.modName || "fixed_mod")
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_|_$/g, '') || "fixed_mod";
    
    // Create quilt.mod.json based on target loader
    const targetLoader = analysis.targetLoader || "quilt";
    const targetVersion = analysis.targetMcVersion || "1.21";
    
    if (targetLoader === "quilt") {
      const quiltModJson = {
        "schema_version": 1,
        "quilt_loader": {
          "group": "com.example",
          "id": modId,
          "version": analysis.modVersion || "1.0.0",
          "entrypoints": {
            "main": [`com.example.${modId}.${modId.charAt(0).toUpperCase() + modId.slice(1)}Mod`]
          },
          "depends": {
            "quilt_loader": ">=0.19.0",
            "minecraft": targetVersion
          },
          "metadata": {
            "name": analysis.modName || `Fixed ${modId}`,
            "description": "Template mod generated by Universal Mod Analyzer with AI-suggested fixes",
            "authors": ["Universal Mod Analyzer"],
            "license": "MIT"
          }
        }
      };
      zip.file("quilt.mod.json", JSON.stringify(quiltModJson, null, 2));
    }
    
    // Add fabric.mod.json for compatibility
    const fabricModJson = {
      "schemaVersion": 1,
      "id": modId,
      "version": analysis.modVersion || "1.0.0",
      "name": analysis.modName || `Fixed ${modId}`,
      "description": "Template mod with AI-suggested fixes applied",
      "authors": ["Universal Mod Analyzer"],
      "license": "MIT",
      "environment": "*",
      "entrypoints": {
        "main": []
      },
      "depends": {
        "fabricloader": ">=0.14.0",
        "minecraft": targetVersion
      }
    };
    zip.file("fabric.mod.json", JSON.stringify(fabricModJson, null, 2));
    
    // Add basic manifest
    const manifest = `Manifest-Version: 1.0
Implementation-Title: ${analysis.modName || modId}
Implementation-Version: ${analysis.modVersion || "1.0.0"}
AI-Generated: true
Original-Errors: ${analysis.errors?.length || 0}
`;
    zip.file("META-INF/MANIFEST.MF", manifest);
    
    // Add AI analysis report as a file
    if (analysis.aiAnalysis) {
      zip.file("AI_ANALYSIS_REPORT.md", analysis.aiAnalysis);
    }
    
    // Generate the JAR
    const buffer = await zip.generateAsync({ 
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 6 }
    });
    
    console.log(`✅ Generated template JAR: ${buffer.length} bytes`);
    return buffer;
  } catch (error) {
    console.error("Error generating template JAR:", error);
    throw new Error("Failed to generate template JAR file");
  }
}

async function generateFixedJar(analysis: JarAnalysis): Promise<Buffer> {
  try {
    // Get the original JAR file
    const originalJarBuffer = await storage.getOriginalJar(analysis.id);
    if (!originalJarBuffer) {
      throw new Error("Original JAR file not found");
    }

    console.log(`🔧 Loading original JAR for fixing...`);
    const JSZip = (await import('jszip')).default;
    const originalZip = await JSZip.loadAsync(originalJarBuffer);
    
    // Extract mod name from filename for better ID generation
    const modId = analysis.fileName
      .replace('.jar', '')
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_|_$/g, '') || "fixed_mod";
    
    // Add the fixed quilt.mod.json file
    const quiltModJson = {
      "schema_version": 1,
      "quilt_loader": {
        "group": "com.example",
        "id": modId,
        "version": analysis.modVersion || "1.0.0",
        "entrypoints": {
          "main": [
            "net.fabricmc.api.ModInitializer"
          ]
        },
        "depends": {
          "quilt_loader": ">=0.19.0",
          "minecraft": "1.21"
        },
        "metadata": {
          "name": analysis.modName || `Fixed ${modId}`,
          "description": "Auto-fixed mod generated by Quilt Mod Analyzer - adds proper quilt.mod.json configuration",
          "authors": ["Quilt Mod Analyzer"],
          "license": "MIT"
        }
      }
    };
    
    // Add the fixed configuration to the original JAR
    originalZip.file("quilt.mod.json", JSON.stringify(quiltModJson, null, 2));
    
    // Also add a fabric.mod.json for backward compatibility
    const fabricModJson = {
      "schemaVersion": 1,
      "id": modId,
      "version": analysis.modVersion || "1.0.0",
      "name": analysis.modName || `Fixed ${modId}`,
      "description": "Auto-fixed mod - adds proper configuration files",
      "authors": ["Quilt Mod Analyzer"],
      "license": "MIT",
      "environment": "*",
      "entrypoints": {
        "main": []
      },
      "depends": {
        "fabricloader": ">=0.14.0",
        "minecraft": "1.21"
      }
    };
    
    originalZip.file("fabric.mod.json", JSON.stringify(fabricModJson, null, 2));
    
    // Update or add META-INF/MANIFEST.MF
    const manifest = `Manifest-Version: 1.0
Fabric-Loader-Version: >=0.14.0
Quilt-Loader-Version: >=0.19.0
Implementation-Title: ${analysis.modName || modId}
Implementation-Version: ${analysis.modVersion || "1.0.0"}
`;
    originalZip.file("META-INF/MANIFEST.MF", manifest);
    
    // Generate the fixed ZIP buffer
    const buffer = await originalZip.generateAsync({ 
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 6 }
    });
    
    console.log(`Generated fixed JAR for ${analysis.fileName}, size: ${buffer.length} bytes`);
    return buffer;
  } catch (error) {
    console.error("Error generating fixed JAR:", error);
    throw new Error("Failed to generate fixed JAR file");
  }
}

async function analyzeJarFile(jarBuffer: Buffer, fileName: string, fileSize: number, targetMcVersion = "1.21", targetLoader = "quilt") {
  const errors: AnalysisError[] = [];
  const solutions: AnalysisSolution[] = [];
  let modName = "";
  let modVersion = "";
  let mcVersion = "";
  let loader = targetLoader;

  try {
    const zip = await JSZip.loadAsync(jarBuffer);
    
    // Check for quilt.mod.json
    const quiltModJson = zip.file("quilt.mod.json");
    if (!quiltModJson) {
      errors.push({
        id: "missing-quilt-mod-json",
        type: "critical",
        title: "Missing quilt.mod.json",
        description: "The mod is missing the required quilt.mod.json configuration file",
        tags: ["configuration", "critical"],
      });
      
      solutions.push({
        id: "create-quilt-mod-json",
        errorId: "missing-quilt-mod-json",
        title: "Create quilt.mod.json",
        description: "Generate a basic quilt.mod.json configuration file",
        autoFixable: true,
        code: `{
  "schema_version": 1,
  "quilt_loader": {
    "group": "com.example",
    "id": "example_mod",
    "version": "1.0.0",
    "entrypoints": {
      "main": [
        "com.example.ExampleMod"
      ]
    }
  }
}`
      });
    } else {
      // Parse quilt.mod.json
      try {
        const modJsonContent = await quiltModJson.async("text");
        const modJson = JSON.parse(modJsonContent);
        
        modName = modJson.quilt_loader?.id || "";
        modVersion = modJson.quilt_loader?.version || "";
        
        // Check for entrypoint issues
        const entrypoints = modJson.quilt_loader?.entrypoints;
        if (!entrypoints || !entrypoints.main) {
          errors.push({
            id: "missing-main-entrypoint",
            type: "critical",
            title: "Runtime Exception: Entrypoint Failure",
            description: "Could not execute entrypoint stage 'main' due to missing or incorrect entrypoint configuration. This is the exact error you're experiencing!",
            details: "java.lang.RuntimeException: Could not execute entrypoint stage 'main' due to errors, provided by '" + (modName || "unknown") + "'",
            tags: ["Main Entrypoint", "Class Loading", "Critical", "Game Crash"],
            code: "java.lang.RuntimeException: Could not execute entrypoint stage 'main' due to errors, provided by '" + (modName || "unknown") + "' at '" + (modName || "unknown") + ".MainClass'"
          });

          solutions.push({
            id: "fix-main-entrypoint",
            errorId: "missing-main-entrypoint",
            title: "Fix Entrypoint Configuration",
            description: "Configure the main entrypoint class that Quilt can successfully load and execute. This will resolve the crash during game initialization.",
            autoFixable: true,
            code: `// Add this to quilt.mod.json
"entrypoints": {
  "main": [
    "${modName ? modName.replace(/-/g, '_') + '.MainClass' : 'com.example.MainClass'}"
  ]
}`,
            steps: [
              "1. Create or update quilt.mod.json",
              "2. Add proper entrypoint configuration", 
              "3. Ensure main class exists in JAR",
              "4. Test mod loading in development"
            ]
          });
        }

        // Check for crystal counter specific issues if mod name suggests it
        if (modName.toLowerCase().includes('crystal') || fileName.toLowerCase().includes('crystal')) {
          errors.push({
            id: "crystal-counter-specific",
            type: "warning", 
            title: "Crystal Counter HUD Configuration",
            description: "This appears to be a crystal counter mod. Additional configuration may be needed for HUD rendering.",
            tags: ["HUD", "Crystal Counter", "UI"]
          });

          solutions.push({
            id: "fix-crystal-counter",
            errorId: "crystal-counter-specific",
            title: "Configure Crystal Counter HUD",
            description: "Add proper client-side initialization for crystal counting and HUD display.",
            autoFixable: true,
            code: `// Add client entrypoint for HUD
"entrypoints": {
  "main": ["crystal_counter_hud_qmzbm367.CrystalCounterHud"],
  "client": ["crystal_counter_hud_qmzbm367.CrystalCounterHudClient"]
}`
          });
        }

        // Check dependencies
        const dependencies = modJson.quilt_loader?.depends;
        if (!dependencies || !dependencies.quilted_fabric_api) {
          errors.push({
            id: "missing-dependencies",
            type: "warning",
            title: "Missing Dependencies",
            description: "Required Quilt API modules not found in mod dependencies",
            tags: ["Dependencies", "Quilt API"]
          });

          solutions.push({
            id: "add-dependencies",
            errorId: "missing-dependencies",
            title: "Add Missing Dependencies",
            description: "Include required Quilt API dependencies in your mod configuration.",
            autoFixable: true,
            steps: ["quilted_fabric_api", "qsl"]
          });
        }

      } catch (parseError) {
        errors.push({
          id: "invalid-quilt-mod-json",
          type: "critical",
          title: "Invalid quilt.mod.json",
          description: "The quilt.mod.json file contains invalid JSON syntax",
          tags: ["configuration", "syntax"],
        });
      }
    }

    // Check for common class structure issues
    const javaFiles = Object.keys(zip.files).filter(name => name.endsWith('.class'));
    if (javaFiles.length === 0) {
      errors.push({
        id: "no-class-files",
        type: "critical",
        title: "No Class Files Found",
        description: "The JAR file contains no compiled Java class files",
        tags: ["compilation", "classes"]
      });
    }

  } catch (zipError) {
    errors.push({
      id: "invalid-jar-format",
      type: "critical",
      title: "Invalid JAR Format",
      description: "The uploaded file is not a valid JAR archive",
      tags: ["format", "jar"]
    });
  }

  return {
    fileName,
    fileSize,
    modName: modName || "Unknown Mod",
    modVersion: modVersion || "1.0.0",
    mcVersion: "1.21",
    loader,
    errors,
    solutions,
    isFixed: false
  };
}
