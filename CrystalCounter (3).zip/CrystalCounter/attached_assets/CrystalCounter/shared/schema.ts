import { pgTable, text, serial, integer, boolean, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const jarAnalyses = pgTable("jar_analyses", {
  id: serial("id").primaryKey(),
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size").notNull(),
  modName: text("mod_name"),
  modVersion: text("mod_version"),
  mcVersion: text("mc_version"),
  loader: text("loader"), // "quilt", "fabric", "forge", "neoforge", "unknown"
  targetMcVersion: text("target_mc_version").default("1.21"), // User selected target version
  targetLoader: text("target_loader").default("quilt"), // User selected target loader
  errors: json("errors").$type<AnalysisError[]>().default([]),
  solutions: json("solutions").$type<AnalysisSolution[]>().default([]),
  aiAnalysis: text("ai_analysis"), // AI-generated analysis of error logs
  errorLog: text("error_log"), // Raw error log input (up to 10M chars)
  isFixed: boolean("is_fixed").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type AnalysisError = {
  id: string;
  type: 'critical' | 'warning' | 'info';
  title: string;
  description: string;
  details?: string;
  tags: string[];
  code?: string;
};

export type AnalysisSolution = {
  id: string;
  errorId: string;
  title: string;
  description: string;
  code?: string;
  autoFixable: boolean;
  steps?: string[];
};

export const insertJarAnalysisSchema = createInsertSchema(jarAnalyses).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertJarAnalysis = z.infer<typeof insertJarAnalysisSchema>;
export type JarAnalysis = typeof jarAnalyses.$inferSelect;
