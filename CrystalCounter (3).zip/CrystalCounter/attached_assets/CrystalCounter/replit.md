# Quilt Mod Analyzer

## Overview

This is a full-stack web application for analyzing Quilt Minecraft mod JAR files. The application provides debugging and repair capabilities for mod developers, helping them identify issues in their mods and providing automated solutions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **File Handling**: JSZip for client-side JAR file processing

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **File Upload**: Multer middleware for handling multipart/form-data
- **Session Management**: PostgreSQL-based session storage with connect-pg-simple

### Project Structure
```
├── client/           # Frontend React application
├── server/           # Backend Express API
├── shared/           # Shared types and schemas
├── migrations/       # Database migration files
└── dist/            # Production build output
```

## Key Components

### Database Schema
- **Users Table**: Basic user authentication (id, username, password)
- **JAR Analyses Table**: Stores analysis results with metadata, errors, and solutions
- **Error/Solution Types**: JSON fields storing structured analysis data

### Core Features
1. **JAR File Upload**: Drag-and-drop interface with file validation
2. **Analysis Engine**: Client-side JAR parsing and validation
3. **Error Detection**: Identifies critical, warning, and info-level issues
4. **Solution Generation**: Provides automated fixes and manual repair steps
5. **Analysis History**: Persistent storage of all analysis results

### UI Components
- **File Upload**: Drag-and-drop with progress indicators
- **Analysis Results**: Detailed error reporting with severity indicators
- **Solutions Section**: Interactive fix application with auto-fix capabilities
- **Sidebar**: Analysis summary and statistics dashboard

## Data Flow

1. **Upload Process**: User uploads JAR file → Multer processes file → Analysis engine parses content
2. **Analysis Pipeline**: Extract mod metadata → Validate structure → Identify errors → Generate solutions
3. **Storage**: Results saved to PostgreSQL → UI updated via React Query
4. **Fix Application**: User applies fixes → Backend processes changes → Analysis updated

## External Dependencies

### Core Runtime
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm**: Type-safe database queries and migrations
- **express**: Web server framework
- **multer**: File upload handling

### Frontend Libraries
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components
- **wouter**: Lightweight routing
- **jszip**: JAR file parsing
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production
- **drizzle-kit**: Database schema management and migrations

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx with file watching for live reload
- **Database**: Drizzle push for schema synchronization

### Production
- **Build Process**: Vite builds frontend to `dist/public`, esbuild bundles backend to `dist/index.js`
- **Deployment**: Single Node.js process serving both API and static files
- **Database**: PostgreSQL migrations applied via Drizzle Kit
- **Environment**: Requires `DATABASE_URL` environment variable

### Recent Changes

#### July 20, 2025 - AI Crash Report Detective Integration
- **JAR + Crash Report Integration**: Enhanced file upload to support both JAR files AND crash reports together for comprehensive analysis
- **AI Crash Report Detective**: Implemented intelligent crash report analysis that works like a detective to find root causes and provide targeted fixes
- **Stack Trace Analysis**: AI examines stack traces to pinpoint exact error locations and generate specific solutions
- **Smart Download System**: Fixed JAR downloads now support both enhanced JAR files and template JARs for crash report-only analyses
- **Template JAR Generation**: Creates proper mod templates with AI analysis reports included for crash report analyses without JAR files
- **Enhanced Pattern Recognition**: AI detects null pointers, runtime crashes, mixin failures, entrypoint issues, and dependency problems from crash logs
- **Universal Version Support**: Full support for ALL Minecraft versions (1.8-1.21) and all major mod loaders (Quilt, Fabric, Forge, NeoForge)
- **Free AI Analysis**: 10 million character crash report analysis with no external API requirements

### Key Design Decisions

1. **Monorepo Structure**: Shared types between frontend and backend reduce duplication
2. **Client-Side Analysis**: JAR parsing in browser reduces server load and improves responsiveness
3. **JSON Error Storage**: Flexible schema allows for evolving error types without migrations
4. **Memory Storage Fallback**: Development can run without database setup
5. **Component Library**: shadcn/ui provides consistent design system with full customization
6. **Session-Based Auth**: Simple authentication suitable for development tools
7. **Auto-Fix Generation**: Comprehensive JAR file generation with proper Quilt configurations

The application prioritizes developer experience with fast iteration cycles, comprehensive error reporting, and automated fix suggestions for common Quilt mod issues.