import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Brain, FileText, Info, Upload, Zap, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface EnhancedAIAnalyzerProps {
  onAnalysisComplete: (analysis: any) => void;
  defaultMcVersion?: string;
  defaultLoader?: string;
}

export default function EnhancedAIAnalyzer({ 
  onAnalysisComplete, 
  defaultMcVersion = "1.21", 
  defaultLoader = "quilt" 
}: EnhancedAIAnalyzerProps) {
  const [targetMcVersion, setTargetMcVersion] = useState(defaultMcVersion);
  const [targetLoader, setTargetLoader] = useState(defaultLoader);
  const [errorLog, setErrorLog] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const minecraftVersions = [
    "1.21", "1.20.6", "1.20.5", "1.20.4", "1.20.3", "1.20.2", "1.20.1", "1.20",
    "1.19.4", "1.19.3", "1.19.2", "1.19.1", "1.19",
    "1.18.2", "1.18.1", "1.18",
    "1.17.1", "1.17",
    "1.16.5", "1.16.4", "1.16.3", "1.16.2", "1.16.1", "1.16",
    "1.15.2", "1.15.1", "1.15",
    "1.14.4", "1.14.3", "1.14.2", "1.14.1", "1.14",
    "1.13.2", "1.13.1", "1.13",
    "1.12.2", "1.12.1", "1.12",
    "1.11.2", "1.11.1", "1.11",
    "1.10.2", "1.10.1", "1.10",
    "1.9.4", "1.9.2", "1.9.1", "1.9",
    "1.8.9", "1.8.8", "1.8"
  ];

  const modLoaders = [
    { value: "quilt", label: "Quilt" },
    { value: "fabric", label: "Fabric" },
    { value: "forge", label: "Forge" },
    { value: "neoforge", label: "NeoForge" }
  ];

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      toast({
        title: "File selected",
        description: `${file.name} (${(file.size / 1024).toFixed(1)} KB) ready for analysis`,
      });
    }
  };

  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };

  const removeFile = () => {
    setUploadedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const startEnhancedAnalysis = async () => {
    if (!errorLog.trim() && !uploadedFile) {
      toast({
        title: "No data provided",
        description: "Please provide either a crash report or upload a JAR file",
        variant: "destructive"
      });
      return;
    }

    if (errorLog.length > 10000000) {
      toast({
        title: "Error log too large",
        description: "Please limit error logs to 10 million characters",
        variant: "destructive"
      });
      return;
    }

    setIsAnalyzing(true);

    try {
      console.log('Starting Enhanced AI Analysis...');
      
      if (uploadedFile) {
        // Analyze with JAR file and optional crash report
        const formData = new FormData();
        formData.append('jarFile', uploadedFile);
        formData.append('targetMcVersion', targetMcVersion);
        formData.append('targetLoader', targetLoader);
        if (errorLog.trim()) {
          formData.append('errorLog', errorLog);
        }

        console.log('FormData created, making API request...');

        const response = await fetch('/api/analyze', {
          method: 'POST',
          body: formData
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({ message: 'Unknown error' }));
          throw new Error(errorData.message || 'Analysis failed');
        }

        const analysis = await response.json();
        console.log('Analysis received:', analysis);

        onAnalysisComplete(analysis);

        toast({
          title: "Enhanced analysis complete",
          description: `Found ${analysis.errors?.length || 0} issues with ${analysis.solutions?.length || 0} targeted solutions`,
        });

      } else {
        // Analyze crash report only
        const response = await fetch('/api/analyze-errorlog', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            errorLog,
            targetMcVersion,
            targetLoader
          })
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({ message: 'Unknown error' }));
          throw new Error(errorData.message || 'Analysis failed');
        }

        const analysis = await response.json();
        console.log('AI analysis received:', analysis);

        // Create virtual analysis structure for crash report only
        const virtualAnalysis = {
          id: Date.now(),
          fileName: "Crash Report Analysis",
          fileSize: 0,
          modName: "AI Analysis",
          modVersion: "Unknown",
          mcVersion: "Various",
          loader: targetLoader,
          targetMcVersion: targetMcVersion,
          targetLoader: targetLoader,
          errors: analysis.errors || [],
          solutions: analysis.solutions || [],
          aiAnalysis: analysis.aiAnalysis || "Analysis completed",
          errorLog: errorLog,
          isFixed: false,
          createdAt: new Date()
        };

        onAnalysisComplete(virtualAnalysis);

        toast({
          title: "AI analysis complete",
          description: `Found ${analysis.errors?.length || 0} issues and ${analysis.solutions?.length || 0} solutions`,
        });
      }

    } catch (error) {
      console.error('Enhanced analysis error:', error);
      toast({
        title: "Analysis failed", 
        description: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-gray-900 dark:text-gray-100">
          <Brain className="w-5 h-5 text-purple-600" />
          Enhanced AI Analysis
          <Badge variant="secondary" className="ml-2">Free</Badge>
          <Badge variant="outline" className="ml-1">AI Detective</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Target Configuration */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-gray-700 dark:text-gray-300">Target Mod Loader</Label>
            <Select value={targetLoader} onValueChange={setTargetLoader}>
              <SelectTrigger className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {modLoaders.map((loader) => (
                  <SelectItem key={loader.value} value={loader.value}>
                    {loader.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-gray-700 dark:text-gray-300">Target Minecraft Version</Label>
            <Select value={targetMcVersion} onValueChange={setTargetMcVersion}>
              <SelectTrigger className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {minecraftVersions.map((version) => (
                  <SelectItem key={version} value={version}>
                    {version}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Separator />

        {/* Crash Report / Error Log */}
        <div className="space-y-3">
          <Label className="text-gray-700 dark:text-gray-300">
            Crash Report / Error Log (Optional)
          </Label>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Paste your crash report or error log for AI-powered root cause analysis and targeted fixes
          </p>
          <Textarea
            placeholder="Paste your crash report, error log, or debug output here (up to 10 million characters)..."
            value={errorLog}
            onChange={(e) => setErrorLog(e.target.value)}
            rows={8}
            className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-gray-100 font-mono text-sm"
          />
          <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
            <span>{errorLog.length.toLocaleString()} / 10,000,000 characters</span>
          </div>
        </div>

        <Separator />

        {/* File Upload */}
        <div className="space-y-3">
          <Label className="text-gray-700 dark:text-gray-300">
            Upload JAR File (Optional)
          </Label>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Upload your JAR file for comprehensive analysis with the crash report
          </p>
          
          <input
            ref={fileInputRef}
            type="file"
            accept=".jar"
            onChange={handleFileUpload}
            className="hidden"
          />

          {uploadedFile ? (
            <div className="flex items-center justify-between bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-green-600 dark:text-green-400" />
                <div>
                  <p className="text-sm font-medium text-green-800 dark:text-green-200">
                    {uploadedFile.name}
                  </p>
                  <p className="text-xs text-green-600 dark:text-green-400">
                    {(uploadedFile.size / 1024).toFixed(1)} KB
                  </p>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={removeFile}
                className="text-red-600 border-red-300 hover:bg-red-50 dark:text-red-400 dark:border-red-700 dark:hover:bg-red-900/20"
              >
                Remove
              </Button>
            </div>
          ) : (
            <button
              onClick={triggerFileUpload}
              className="w-full border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center hover:border-primary dark:hover:border-primary transition-colors"
            >
              <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400 dark:text-gray-500" />
              <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                Click to upload JAR file
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Supports .jar files up to 100MB
              </p>
            </button>
          )}
        </div>

        {/* Analysis Button */}
        <Button 
          onClick={startEnhancedAnalysis}
          disabled={isAnalyzing || (!errorLog.trim() && !uploadedFile)}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white"
          size="lg"
        >
          {isAnalyzing ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Running Enhanced AI Analysis...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 mr-2" />
              Start Enhanced AI Analysis
            </>
          )}
        </Button>

        {isAnalyzing && (
          <div className="space-y-2">
            <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4 border border-purple-200 dark:border-purple-800">
              <div className="flex items-center gap-2 text-purple-800 dark:text-purple-200 mb-2">
                <Info className="w-4 h-4" />
                <span className="text-sm font-medium">AI Detective at work...</span>
              </div>
              <div className="text-sm text-purple-700 dark:text-purple-300 space-y-1">
                <p>• Examining crash patterns and stack traces</p>
                <p>• Identifying root causes and dependencies</p>
                <p>• Generating targeted fixes for {targetLoader} {targetMcVersion}</p>
                <p>• Creating comprehensive analysis report</p>
              </div>
            </div>
          </div>
        )}

        {/* Info Box */}
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
          <div className="flex items-start gap-2">
            <Info className="w-4 h-4 text-blue-600 dark:text-blue-400 mt-0.5" />
            <div className="text-sm text-blue-800 dark:text-blue-200">
              <p className="font-medium mb-1">Enhanced AI Analysis Features:</p>
              <ul className="space-y-1 text-xs">
                <li>• Intelligent crash report detective that finds root causes</li>
                <li>• Combined JAR + crash report analysis for maximum accuracy</li>
                <li>• Support for ALL Minecraft versions (1.8-1.21) and mod loaders</li>
                <li>• Targeted fixes specific to your configuration</li>
                <li>• Free 10 million character analysis with no API keys required</li>
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}