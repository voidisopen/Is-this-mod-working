import { useState, useRef } from "react";
import { CloudUpload, FolderOpen, Bug, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { type JarAnalysis } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Button } from "@/components/ui/button";

interface FileUploadProps {
  onAnalysisComplete: (analysis: JarAnalysis) => void;
}

export default function FileUpload({ onAnalysisComplete }: FileUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [crashReport, setCrashReport] = useState("");
  const [targetMcVersion, setTargetMcVersion] = useState("1.21");
  const [targetLoader, setTargetLoader] = useState("quilt");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileUpload = async (file: File) => {
    if (!file.name.endsWith('.jar')) {
      toast({
        title: "Invalid file type",
        description: "Please upload a .jar file",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);
    
    try {
      console.log('Starting file upload:', file.name, 'Size:', file.size);
      
      const formData = new FormData();
      formData.append('jarFile', file);
      formData.append('targetMcVersion', targetMcVersion);
      formData.append('targetLoader', targetLoader);
      if (crashReport.trim()) {
        formData.append('crashReport', crashReport);
      }

      console.log('FormData created, making API request...');
      const response = await apiRequest('POST', '/api/analyze', formData);
      const analysis = await response.json();
      
      console.log('Analysis received:', analysis);
      
      onAnalysisComplete(analysis);
      
      const errorCount = analysis.errors.length;
      const hasAI = crashReport.trim().length > 0;
      
      toast({
        title: hasAI ? "AI-Enhanced Analysis Complete" : "Analysis Complete",
        description: hasAI 
          ? `Found ${errorCount} issues using JAR analysis + AI crash report detection`
          : `Found ${errorCount} issues in ${file.name}`,
      });
      
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Analysis failed",
        description: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    console.log('Drop event triggered');
    const files = Array.from(e.dataTransfer.files);
    console.log('Files dropped:', files.map(f => f.name));
    
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    console.log('File input change triggered');
    console.log('Files selected:', files ? Array.from(files).map(f => f.name) : 'none');
    
    if (files && files.length > 0) {
      handleFileUpload(files[0]);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Main Upload Area */}
      <div 
        className={`bg-white dark:bg-gray-900 rounded-xl border-2 border-dashed transition-colors p-8 text-center cursor-pointer
          ${dragOver ? 'border-primary bg-primary/5' : 'border-slate-300 dark:border-gray-700 hover:border-primary'}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={(e) => {
          e.preventDefault();
          setDragOver(false);
        }}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".jar"
          onChange={handleFileSelect}
          className="hidden"
        />
        
        <div className="mb-4">
          <div className="bg-slate-100 dark:bg-gray-800 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
            <CloudUpload className="w-8 h-8 text-slate-600 dark:text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-slate-900 dark:text-gray-100 mb-2">
            {isUploading ? "Analyzing JAR File..." : "Upload JAR File + Crash Report"}
          </h3>
          <p className="text-slate-600 dark:text-gray-400 mb-4">
            {isUploading 
              ? "AI analyzing JAR structure and crash reports..." 
              : "Get AI-powered fixes for all mod loaders (Quilt, Fabric, Forge, NeoForge) and Minecraft 1.8-1.21"
            }
          </p>
        </div>
        
        {isUploading ? (
          <div className="space-y-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <div className="bg-slate-100 dark:bg-gray-700 rounded-full h-2 max-w-md mx-auto">
              <div className="bg-primary h-2 rounded-full w-2/3 transition-all duration-1000"></div>
            </div>
            <p className="text-sm text-slate-500 dark:text-gray-400">Running AI crash analysis and JAR fixing...</p>
          </div>
        ) : (
          <div className="flex flex-col sm:flex-row gap-3 justify-center items-center">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="bg-primary hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center"
            >
              <FolderOpen className="w-5 h-5 mr-2" />
              Browse Files
            </button>
            <span className="text-slate-500 dark:text-gray-400 text-sm">or drag and drop</span>
          </div>
        )}
        
        {!isUploading && (
          <p className="text-xs text-slate-500 dark:text-gray-400 mt-4">Supports .jar files up to 50MB • Free AI analysis</p>
        )}
      </div>

      {/* Advanced Options */}
      <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
        <CollapsibleTrigger asChild>
          <Button variant="outline" className="w-full">
            <Settings className="w-4 h-4 mr-2" />
            {showAdvanced ? 'Hide' : 'Show'} Advanced Options & Crash Report Analysis
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bug className="w-5 h-5" />
                Enhanced AI Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Target Configuration */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="target-loader">Target Mod Loader</Label>
                  <Select value={targetLoader} onValueChange={setTargetLoader}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="quilt">Quilt</SelectItem>
                      <SelectItem value="fabric">Fabric</SelectItem>
                      <SelectItem value="forge">Forge</SelectItem>
                      <SelectItem value="neoforge">NeoForge</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="target-version">Target Minecraft Version</Label>
                  <Select value={targetMcVersion} onValueChange={setTargetMcVersion}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1.21">1.21</SelectItem>
                      <SelectItem value="1.20.6">1.20.6</SelectItem>
                      <SelectItem value="1.20.4">1.20.4</SelectItem>
                      <SelectItem value="1.20.1">1.20.1</SelectItem>
                      <SelectItem value="1.19.4">1.19.4</SelectItem>
                      <SelectItem value="1.19.2">1.19.2</SelectItem>
                      <SelectItem value="1.18.2">1.18.2</SelectItem>
                      <SelectItem value="1.17.1">1.17.1</SelectItem>
                      <SelectItem value="1.16.5">1.16.5</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Crash Report Input */}
              <div>
                <Label htmlFor="crash-report" className="flex items-center gap-2">
                  <Bug className="w-4 h-4" />
                  Crash Report / Error Log (Optional)
                </Label>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                  Paste your crash report or error log for AI-powered root cause analysis and targeted fixes
                </p>
                <Textarea
                  id="crash-report"
                  placeholder="Paste your crash report here...

Example:
---- Minecraft Crash Report ----
// Error details here

Time: 2025-07-20 08:27:17
Description: Initializing game

java.lang.RuntimeException: Could not execute entrypoint...
  at net.fabricmc.loader.impl.entrypoint.EntrypointUtils.invoke(EntrypointUtils.java:53)
  ..."
                  value={crashReport}
                  onChange={(e) => setCrashReport(e.target.value)}
                  className="min-h-[200px] font-mono text-sm"
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Supports up to 10 million characters • Free AI analysis • No external API required
                </p>
              </div>
            </CardContent>
          </Card>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}
