import { useState } from "react";
import { Wrench, Wand2, Download, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { type JarAnalysis } from "@shared/schema";

interface SolutionsSectionProps {
  analysis: JarAnalysis;
  onFixApplied: () => void;
}

export default function SolutionsSection({ analysis, onFixApplied }: SolutionsSectionProps) {
  const [isApplyingFix, setIsApplyingFix] = useState<string | null>(null);
  const { toast } = useToast();

  const downloadAnalysisReport = (analysis: JarAnalysis) => {
    const report = {
      fileName: analysis.fileName,
      modName: analysis.modName,
      modVersion: analysis.modVersion,
      mcVersion: analysis.mcVersion,
      loader: analysis.loader,
      analysisDate: analysis.createdAt,
      errors: analysis.errors,
      solutions: analysis.solutions,
      isFixed: analysis.isFixed
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${analysis.fileName.replace('.jar', '')}_analysis_report.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Report downloaded",
      description: "Analysis report has been saved to your downloads folder",
    });
  };

  const handleAutoFix = async (solutionId: string) => {
    setIsApplyingFix(solutionId);
    
    try {
      await apiRequest('POST', `/api/analyses/${analysis.id}/fix`, { solutionId });
      
      toast({
        title: "Fix applied successfully",
        description: "The issue has been automatically resolved",
      });
      
      onFixApplied();
    } catch (error) {
      toast({
        title: "Fix failed",
        description: "Failed to apply the automatic fix",
        variant: "destructive"
      });
    } finally {
      setIsApplyingFix(null);
    }
  };

  if (analysis.solutions.length === 0) {
    return null;
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200">
      <div className="border-b border-slate-200 px-6 py-4">
        <h2 className="text-lg font-semibold text-slate-900 flex items-center">
          <Wrench className="w-5 h-5 mr-3 text-success" />
          Suggested Solutions
        </h2>
      </div>
      
      <div className="p-6 space-y-4">
        {analysis.solutions.map((solution, index) => (
          <div 
            key={solution.id}
            className="border border-success/20 rounded-lg bg-success/5 p-4"
          >
            <div className="flex items-start space-x-3">
              <div className="bg-success text-white rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-bold">{index + 1}</span>
              </div>
              <div className="flex-1">
                <h6 className="font-semibold text-success mb-2">{solution.title}</h6>
                <p className="text-sm text-slate-700 mb-3">
                  {solution.description}
                </p>
                
                {solution.code && (
                  <div className="bg-slate-900 rounded-lg p-3 mb-3">
                    <code className="text-green-400 text-xs font-mono whitespace-pre-wrap">
                      {solution.code}
                    </code>
                  </div>
                )}
                
                {solution.steps && (
                  <div className="space-y-2 mb-3">
                    {solution.steps.map((step, stepIndex) => (
                      <div key={stepIndex} className="flex items-center justify-between bg-white rounded border p-2">
                        <span className="text-sm font-mono">{step}</span>
                        <span className="text-xs text-success bg-success/10 px-2 py-1 rounded">
                          Available
                        </span>
                      </div>
                    ))}
                  </div>
                )}
                
                {solution.autoFixable && (
                  <button 
                    onClick={() => handleAutoFix(solution.id)}
                    disabled={isApplyingFix === solution.id}
                    className="bg-success hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 flex items-center"
                  >
                    <Wand2 className="w-4 h-4 mr-2" />
                    {isApplyingFix === solution.id ? "Applying..." : "Auto-Fix This Issue"}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
        
        {/* Download Fixed Version */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-slate-200">
          <a 
            href={`/api/analyses/${analysis.id}/download`}
            download
            className="bg-success hover:bg-green-600 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center justify-center"
          >
            <Download className="w-5 h-5 mr-2" />
            Download Fixed JAR
          </a>
          <button 
            onClick={() => downloadAnalysisReport(analysis)}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-6 py-3 rounded-lg font-medium transition-colors flex items-center justify-center"
          >
            <FileText className="w-5 h-5 mr-2" />
            Export Analysis Report
          </button>
        </div>
      </div>
    </div>
  );
}
