import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Brain, Upload, FileText, AlertTriangle, CheckCircle, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AIErrorAnalyzerProps {
  onAnalysisComplete: (analysis: string, errors: any[], solutions: any[]) => void;
  targetMcVersion: string;
  targetLoader: string;
}

// Basic AI-like analysis patterns for common Minecraft mod errors
const ERROR_PATTERNS = [
  {
    pattern: /entrypoint.*not.*found|main.*class.*not.*found|no.*main.*manifest/i,
    type: "critical",
    title: "Missing Entrypoint",
    description: "The mod is missing a proper entrypoint configuration",
    solutions: ["Add fabric.mod.json or quilt.mod.json", "Configure main class in manifest", "Set proper entrypoint values"]
  },
  {
    pattern: /mixin.*failed|mixin.*error|@mixin/i,
    type: "critical", 
    title: "Mixin Error",
    description: "Mixin framework issues detected",
    solutions: ["Update mixin mappings", "Check mixin configuration", "Verify target class exists"]
  },
  {
    pattern: /dependency.*not.*found|missing.*dependency|requires.*mod/i,
    type: "warning",
    title: "Missing Dependencies",
    description: "Required dependencies are not available",
    solutions: ["Install missing dependencies", "Update dependency versions", "Check mod compatibility"]
  },
  {
    pattern: /version.*mismatch|incompatible.*version|wrong.*version/i,
    type: "warning",
    title: "Version Incompatibility",
    description: "Version conflicts detected",
    solutions: ["Update to compatible versions", "Check version requirements", "Use version ranges"]
  },
  {
    pattern: /classnotfound|noclassdeffounderror/i,
    type: "critical",
    title: "Missing Classes",
    description: "Required classes are not found",
    solutions: ["Check classpath", "Verify mod loading order", "Add missing libraries"]
  },
  {
    pattern: /fabric.*loader|quilt.*loader|forge.*error/i,
    type: "warning",
    title: "Loader Issues",
    description: "Mod loader specific problems",
    solutions: ["Update mod loader", "Check loader compatibility", "Verify mod format"]
  }
];

export default function AIErrorAnalyzer({ onAnalysisComplete, targetMcVersion, targetLoader }: AIErrorAnalyzerProps) {
  const [errorLog, setErrorLog] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();

  const analyzeErrorLog = async () => {
    if (!errorLog.trim()) {
      toast({
        title: "No error log provided",
        description: "Please paste your error log or crash report",
        variant: "destructive"
      });
      return;
    }

    if (errorLog.length > 10000000) { // 10 million character limit
      toast({
        title: "Error log too large",
        description: "Please limit error logs to 10 million characters",
        variant: "destructive"
      });
      return;
    }

    setIsAnalyzing(true);

    try {
      console.log('Starting AI error log analysis...');
      
      const response = await fetch('/api/analyze-errorlog', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          errorLog,
          targetMcVersion,
          targetLoader
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Unknown error' }));
        throw new Error(errorData.message || 'Analysis failed');
      }

      const analysis = await response.json();
      
      console.log('AI analysis received:', analysis);
      
      onAnalysisComplete(analysis.aiAnalysis || "Analysis completed", analysis.errors || [], analysis.solutions || []);

      toast({
        title: "Analysis complete",
        description: `Found ${analysis.errors?.length || 0} issues and ${analysis.solutions?.length || 0} solutions`,
      });

    } catch (error) {
      console.error('AI analysis error:', error);
      toast({
        title: "Analysis failed",
        description: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };



  return (
    <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-gray-900 dark:text-gray-100">
          <Brain className="w-5 h-5 text-purple-600" />
          AI Error Log Analyzer
          <Badge variant="secondary" className="ml-2">Free</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label className="text-gray-700 dark:text-gray-300">Error Log / Crash Report</Label>
          <Textarea
            placeholder="Paste your error log, crash report, or debug output here (up to 10 million characters)..."
            value={errorLog}
            onChange={(e) => setErrorLog(e.target.value)}
            rows={8}
            className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-gray-100 font-mono text-sm"
          />
          <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
            <span>{errorLog.length.toLocaleString()} / 10,000,000 characters</span>
            <span>Target: {targetLoader} {targetMcVersion}</span>
          </div>
        </div>

        <div className="flex gap-2">
          <Button 
            onClick={analyzeErrorLog}
            disabled={isAnalyzing || !errorLog.trim()}
            className="flex-1"
          >
            {isAnalyzing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Analyzing...
              </>
            ) : (
              <>
                <FileText className="w-4 h-4 mr-2" />
                Analyze Error Log
              </>
            )}
          </Button>
        </div>

        {isAnalyzing && (
          <div className="space-y-2">
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 border border-blue-200 dark:border-blue-800">
              <div className="flex items-center gap-2 text-blue-800 dark:text-blue-200">
                <Info className="w-4 h-4" />
                <span className="text-sm">Analyzing error patterns and generating solutions...</span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}