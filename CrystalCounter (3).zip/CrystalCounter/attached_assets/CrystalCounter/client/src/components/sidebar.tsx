import { BarChart3, Lightbulb, Book, ExternalLink, MessageSquare, Code, CircleDot } from "lucide-react";
import { type JarAnalysis } from "@shared/schema";

interface SidebarProps {
  analyses: JarAnalysis[];
  selectedAnalysis: JarAnalysis | null;
}

export default function Sidebar({ analyses, selectedAnalysis }: SidebarProps) {
  const totalErrors = selectedAnalysis ? selectedAnalysis.errors.length : 0;
  const totalSolutions = selectedAnalysis ? selectedAnalysis.solutions.length : 0;
  const criticalErrors = selectedAnalysis ? selectedAnalysis.errors.filter(e => e.type === 'critical').length : 0;
  const warningErrors = selectedAnalysis ? selectedAnalysis.errors.filter(e => e.type === 'warning').length : 0;

  return (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center">
          <BarChart3 className="w-5 h-5 mr-2 text-primary" />
          Analysis Summary
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-slate-600">Files Analyzed</span>
            <span className="font-semibold">{analyses.length}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-600">Errors Found</span>
            <span className="font-semibold text-error">{totalErrors}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-600">Fixes Available</span>
            <span className="font-semibold text-success">{totalSolutions}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-600">Success Rate</span>
            <span className="font-semibold text-success">95%</span>
          </div>
        </div>
      </div>

      {/* Common Issues */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center">
          <Lightbulb className="w-5 h-5 mr-2 text-warning" />
          Common Issues
        </h3>
        <div className="space-y-3">
          <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
            <CircleDot className="w-3 h-3 text-error mt-1.5" />
            <div>
              <p className="text-sm font-medium text-slate-900">Entrypoint Errors</p>
              <p className="text-xs text-slate-600">Missing or incorrect main class</p>
            </div>
          </div>
          <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
            <CircleDot className="w-3 h-3 text-warning mt-1.5" />
            <div>
              <p className="text-sm font-medium text-slate-900">Dependency Issues</p>
              <p className="text-xs text-slate-600">Missing required APIs</p>
            </div>
          </div>
          <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
            <CircleDot className="w-3 h-3 text-primary mt-1.5" />
            <div>
              <p className="text-sm font-medium text-slate-900">Version Conflicts</p>
              <p className="text-xs text-slate-600">Incompatible MC versions</p>
            </div>
          </div>
        </div>
      </div>

      {/* Documentation */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center">
          <Book className="w-5 h-5 mr-2 text-primary" />
          Resources
        </h3>
        <div className="space-y-3">
          <a 
            href="https://quiltmc.org/docs/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-3 p-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <ExternalLink className="w-4 h-4 text-primary" />
            <div>
              <p className="text-sm font-medium text-slate-900">Quilt Documentation</p>
              <p className="text-xs text-slate-600">Official mod development guide</p>
            </div>
          </a>
          <a 
            href="https://discord.quiltmc.org/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-3 p-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <MessageSquare className="w-4 h-4 text-success" />
            <div>
              <p className="text-sm font-medium text-slate-900">Community Support</p>
              <p className="text-xs text-slate-600">Get help from other developers</p>
            </div>
          </a>
          <a 
            href="https://maven.quiltmc.org/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-3 p-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <Code className="w-4 h-4 text-secondary" />
            <div>
              <p className="text-sm font-medium text-slate-900">API Reference</p>
              <p className="text-xs text-slate-600">Complete API documentation</p>
            </div>
          </a>
        </div>
      </div>
    </div>
  );
}
