import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface VersionSelectorProps {
  onSelectionChange: (targetMcVersion: string, targetLoader: string) => void;
  defaultMcVersion?: string;
  defaultLoader?: string;
}

const MC_VERSIONS = [
  "1.21.4", "1.21.3", "1.21.2", "1.21.1", "1.21",
  "1.20.6", "1.20.5", "1.20.4", "1.20.3", "1.20.2", "1.20.1", "1.20",
  "1.19.4", "1.19.3", "1.19.2", "1.19.1", "1.19",
  "1.18.2", "1.18.1", "1.18",
  "1.17.1", "1.17",
  "1.16.5", "1.16.4", "1.16.3", "1.16.2", "1.16.1", "1.16",
  "1.15.2", "1.15.1", "1.15",
  "1.14.4", "1.14.3", "1.14.2", "1.14.1", "1.14",
  "1.13.2", "1.13.1", "1.13",
  "1.12.2", "1.12.1", "1.12",
  "1.11.2", "1.11.1", "1.11",
  "1.10.2", "1.10.1", "1.10",
  "1.9.4", "1.9.3", "1.9.2", "1.9.1", "1.9",
  "1.8.9", "1.8.8", "1.8.7", "1.8.6", "1.8.5", "1.8.4", "1.8.3", "1.8.2", "1.8.1", "1.8"
];

const LOADERS = [
  { value: "quilt", label: "Quilt", description: "Modern fabric-compatible loader" },
  { value: "fabric", label: "Fabric", description: "Lightweight modding platform" },
  { value: "forge", label: "Forge", description: "Traditional modding framework" },
  { value: "neoforge", label: "NeoForge", description: "Community fork of Forge" }
];

export default function VersionSelector({ onSelectionChange, defaultMcVersion = "1.21", defaultLoader = "quilt" }: VersionSelectorProps) {
  const [targetMcVersion, setTargetMcVersion] = useState(defaultMcVersion);
  const [targetLoader, setTargetLoader] = useState(defaultLoader);

  const handleMcVersionChange = (version: string) => {
    setTargetMcVersion(version);
    onSelectionChange(version, targetLoader);
  };

  const handleLoaderChange = (loader: string) => {
    setTargetLoader(loader);
    onSelectionChange(targetMcVersion, loader);
  };

  return (
    <Card className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="text-gray-900 dark:text-gray-100">Target Configuration</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label className="text-gray-700 dark:text-gray-300">Minecraft Version</Label>
          <Select value={targetMcVersion} onValueChange={handleMcVersionChange}>
            <SelectTrigger className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-gray-100">
              <SelectValue placeholder="Select Minecraft version" />
            </SelectTrigger>
            <SelectContent className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600">
              {MC_VERSIONS.map((version) => (
                <SelectItem key={version} value={version} className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">
                  {version}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label className="text-gray-700 dark:text-gray-300">Mod Loader</Label>
          <Select value={targetLoader} onValueChange={handleLoaderChange}>
            <SelectTrigger className="bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-gray-100">
              <SelectValue placeholder="Select mod loader" />
            </SelectTrigger>
            <SelectContent className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600">
              {LOADERS.map((loader) => (
                <SelectItem key={loader.value} value={loader.value} className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">
                  <div>
                    <div className="font-medium">{loader.label}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{loader.description}</div>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
          <p className="text-sm text-blue-800 dark:text-blue-200">
            <strong>Selected:</strong> {targetLoader.charAt(0).toUpperCase() + targetLoader.slice(1)} for Minecraft {targetMcVersion}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}