import { Archive, SearchCode, X, AlertTriangle } from "lucide-react";
import { type JarAnalysis, type AnalysisError } from "@shared/schema";

interface AnalysisResultsProps {
  analysis: JarAnalysis;
}

export default function AnalysisResults({ analysis }: AnalysisResultsProps) {
  const getErrorIcon = (type: AnalysisError['type']) => {
    switch (type) {
      case 'critical':
        return <X className="text-sm" />;
      case 'warning':
        return <AlertTriangle className="text-sm" />;
      default:
        return <AlertTriangle className="text-sm" />;
    }
  };

  const getErrorColor = (type: AnalysisError['type']) => {
    switch (type) {
      case 'critical':
        return 'error';
      case 'warning':
        return 'warning';
      default:
        return 'secondary';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200">
      <div className="border-b border-slate-200 px-6 py-4">
        <h2 className="text-lg font-semibold text-slate-900 flex items-center">
          <SearchCode className="w-5 h-5 mr-3 text-primary" />
          Analysis Results
        </h2>
      </div>
      
      <div className="p-6">
        <div className="space-y-4">
          {/* File Info */}
          <div className="bg-slate-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <Archive className="w-5 h-5 text-slate-600" />
                <div>
                  <h4 className="font-medium text-slate-900">{analysis.fileName}</h4>
                  <p className="text-sm text-slate-600">{analysis.modName}</p>
                </div>
              </div>
              <span className={`text-sm px-3 py-1 rounded-full font-medium ${
                analysis.errors.length > 0
                  ? 'bg-error/10 text-error'
                  : 'bg-success/10 text-success'
              }`}>
                {analysis.errors.length > 0 ? (
                  <>
                    <AlertTriangle className="w-4 h-4 mr-1 inline" />
                    Errors Found
                  </>
                ) : (
                  'No Issues'
                )}
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="text-slate-600">Size:</span>
                <span className="font-medium ml-2">{(analysis.fileSize / 1024 / 1024).toFixed(1)} MB</span>
              </div>
              <div>
                <span className="text-slate-600">Mod Version:</span>
                <span className="font-medium ml-2">{analysis.modVersion}</span>
              </div>
              <div>
                <span className="text-slate-600">MC Version:</span>
                <span className="font-medium ml-2">{analysis.mcVersion}</span>
              </div>
              <div>
                <span className="text-slate-600">Loader:</span>
                <span className="font-medium ml-2">{analysis.loader}</span>
              </div>
            </div>
          </div>

          {/* Error Details */}
          {analysis.errors.length > 0 && (
            <div className="space-y-3">
              <h5 className="font-semibold text-slate-900 flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2 text-error" />
                Detected Issues
              </h5>
              
              {analysis.errors.map((error) => (
                <div 
                  key={error.id}
                  className={`border rounded-lg ${
                    error.type === 'critical' 
                      ? 'border-error/20 bg-error/5' 
                      : 'border-warning/20 bg-warning/5'
                  }`}
                >
                  <div className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className={`rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5 ${
                        error.type === 'critical' 
                          ? 'bg-error text-white' 
                          : 'bg-warning text-white'
                      }`}>
                        {getErrorIcon(error.type)}
                      </div>
                      <div className="flex-1">
                        <h6 className={`font-semibold mb-2 ${
                          error.type === 'critical' ? 'text-error' : 'text-warning'
                        }`}>
                          {error.title}
                        </h6>
                        <p className="text-sm text-slate-700 mb-3">
                          {error.description}
                        </p>
                        {error.code && (
                          <div className="bg-slate-900 rounded-lg p-3 mb-3">
                            <code className="text-green-400 text-xs font-mono whitespace-pre-wrap">
                              {error.code}
                            </code>
                          </div>
                        )}
                        <div className="flex flex-wrap gap-2">
                          {error.tags.map((tag) => (
                            <span 
                              key={tag}
                              className={`text-xs px-2 py-1 rounded-full ${
                                error.type === 'critical' 
                                  ? 'bg-error/10 text-error' 
                                  : 'bg-warning/10 text-warning'
                              }`}
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
