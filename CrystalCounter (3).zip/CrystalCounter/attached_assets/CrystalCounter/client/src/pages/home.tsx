import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Box, HelpCircle } from "lucide-react";
import AnalysisResults from "@/components/analysis-results";
import SolutionsSection from "@/components/solutions-section";
import Sidebar from "@/components/sidebar";
import EnhancedAIAnalyzer from "@/components/enhanced-ai-analyzer";
import { ThemeToggle } from "@/components/theme-toggle";
import { type JarAnalysis } from "@shared/schema";

export default function Home() {
  const [selectedAnalysis, setSelectedAnalysis] = useState<JarAnalysis | null>(null);
  const [targetMcVersion, setTargetMcVersion] = useState("1.21");
  const [targetLoader, setTargetLoader] = useState("quilt");
  
  const { data: analyses = [], refetch } = useQuery<JarAnalysis[]>({
    queryKey: ["/api/analyses"],
  });

  const handleEnhancedAnalysisComplete = (analysis: JarAnalysis) => {
    setSelectedAnalysis(analysis);
    refetch();
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-slate-200 dark:border-gray-700 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-primary rounded-lg p-2">
              <Box className="text-white text-xl w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 dark:text-gray-100">Universal Mod Analyzer</h1>
              <p className="text-sm text-slate-600 dark:text-gray-400">Fix ANY JAR file for ALL versions (1.8-1.21) - Every single issue!</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-slate-600 dark:text-gray-400">Supports: {targetLoader} {targetMcVersion}</span>
            <ThemeToggle />
            <button className="bg-slate-100 dark:bg-gray-700 hover:bg-slate-200 dark:hover:bg-gray-600 px-3 py-2 rounded-lg text-sm font-medium text-slate-700 dark:text-gray-300 transition-colors flex items-center">
              <HelpCircle className="w-4 h-4 mr-2" />
              Help
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Enhanced AI Analysis */}
            <EnhancedAIAnalyzer 
              onAnalysisComplete={handleEnhancedAnalysisComplete}
              defaultMcVersion={targetMcVersion}
              defaultLoader={targetLoader}
            />
            
            {selectedAnalysis && (
              <>
                <AnalysisResults analysis={selectedAnalysis} />
                <SolutionsSection 
                  analysis={selectedAnalysis} 
                  onFixApplied={() => refetch()} 
                />
              </>
            )}
          </div>

          {/* Sidebar */}
          <Sidebar analyses={analyses} selectedAnalysis={selectedAnalysis} />
        </div>
      </div>
    </div>
  );
}
