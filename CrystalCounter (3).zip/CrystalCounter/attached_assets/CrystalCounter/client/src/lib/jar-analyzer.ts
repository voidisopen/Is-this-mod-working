import JSZip from "jszip";

export interface JarAnalysisResult {
  modName: string;
  modVersion: string;
  mcVersion: string;
  loader: 'quilt' | 'fabric' | 'forge' | 'neoforge' | 'unknown';
  targetMcVersion: string;
  targetLoader: string;
  errors: AnalysisError[];
  solutions: AnalysisSolution[];
  aiAnalysis?: string;
  errorLog?: string;
}

export interface AnalysisError {
  id: string;
  type: 'critical' | 'warning' | 'info';
  title: string;
  description: string;
  details?: string;
  tags: string[];
  code?: string;
}

export interface AnalysisSolution {
  id: string;
  errorId: string;
  title: string;
  description: string;
  code?: string;
  autoFixable: boolean;
  steps?: string[];
}

export class JarAnalyzer {
  static async analyzeJarFile(
    jarBuffer: ArrayBuffer, 
    targetMcVersion: string = "1.21", 
    targetLoader: string = "quilt"
  ): Promise<JarAnalysisResult> {
    const errors: AnalysisError[] = [];
    const solutions: AnalysisSolution[] = [];
    let modName = "";
    let modVersion = "";
    let mcVersion = "";
    let detectedLoader: 'quilt' | 'fabric' | 'forge' | 'neoforge' | 'unknown' = "unknown";

    try {
      const zip = await JSZip.loadAsync(jarBuffer);
      
      // Detect mod loader and extract metadata
      const loaderInfo = await this.detectModLoader(zip);
      detectedLoader = loaderInfo.loader;
      modName = loaderInfo.modName || "Unknown Mod";
      modVersion = loaderInfo.modVersion || "1.0.0";
      mcVersion = loaderInfo.mcVersion || targetMcVersion;
      
      // Generate appropriate errors and solutions based on detected and target loader
      const analysisResult = await this.analyzeForLoader(zip, detectedLoader, targetLoader as any, targetMcVersion);
      errors.push(...analysisResult.errors);
      solutions.push(...analysisResult.solutions);

    } catch (error) {
      errors.push({
        id: "analysis-error",
        type: "critical",
        title: "Analysis Failed",
        description: `Failed to analyze JAR file: ${error.message}`,
        tags: ["analysis", "critical"],
      });
    }

    return {
      modName,
      modVersion,
      mcVersion,
      loader: detectedLoader,
      targetMcVersion,
      targetLoader,
      errors,
      solutions,
    };
  }

  private static async detectModLoader(zip: JSZip): Promise<{
    loader: 'quilt' | 'fabric' | 'forge' | 'neoforge' | 'unknown';
    modName?: string;
    modVersion?: string;
    mcVersion?: string;
  }> {
    let modName = "";
    let modVersion = "";
    let mcVersion = "";

    // Check for Quilt
    const quiltModJson = zip.file("quilt.mod.json");
    if (quiltModJson) {
      try {
        const content = await quiltModJson.async("text");
        const data = JSON.parse(content);
        modName = data.quilt_loader?.metadata?.name || data.quilt_loader?.id || "";
        modVersion = data.quilt_loader?.version || "";
        mcVersion = this.extractMinecraftVersion(data.quilt_loader?.depends?.minecraft);
        return { loader: "quilt", modName, modVersion, mcVersion };
      } catch (e) {
        // Corrupted quilt.mod.json
      }
    }

    // Check for Fabric
    const fabricModJson = zip.file("fabric.mod.json");
    if (fabricModJson) {
      try {
        const content = await fabricModJson.async("text");
        const data = JSON.parse(content);
        modName = data.name || data.id || "";
        modVersion = data.version || "";
        mcVersion = this.extractMinecraftVersion(data.depends?.minecraft);
        return { loader: "fabric", modName, modVersion, mcVersion };
      } catch (e) {
        // Corrupted fabric.mod.json
      }
    }

    // Check for Forge/NeoForge (mods.toml in META-INF)
    const modsToml = zip.file("META-INF/mods.toml");
    if (modsToml) {
      try {
        const content = await modsToml.async("text");
        // Basic TOML parsing for mod info
        const modIdMatch = content.match(/modId\s*=\s*"([^"]+)"/);
        const versionMatch = content.match(/version\s*=\s*"([^"]+)"/);
        const mcVersionMatch = content.match(/minecraftVersion\s*=\s*"([^"]+)"/);
        const displayNameMatch = content.match(/displayName\s*=\s*"([^"]+)"/);
        
        modName = displayNameMatch?.[1] || modIdMatch?.[1] || "";
        modVersion = versionMatch?.[1] || "";
        mcVersion = mcVersionMatch?.[1] || "";
        
        // Detect if it's NeoForge (check for neoforge dependencies)
        const isNeoForge = content.includes("neoforge") || content.includes("NeoForge");
        return { 
          loader: isNeoForge ? "neoforge" : "forge", 
          modName, 
          modVersion, 
          mcVersion 
        };
      } catch (e) {
        // Corrupted mods.toml
      }
    }

    // Check for old Forge (mcmod.info)
    const mcmodInfo = zip.file("mcmod.info");
    if (mcmodInfo) {
      try {
        const content = await mcmodInfo.async("text");
        const data = JSON.parse(content);
        const modInfo = Array.isArray(data) ? data[0] : data;
        modName = modInfo.name || modInfo.modid || "";
        modVersion = modInfo.version || "";
        mcVersion = modInfo.mcversion || "";
        return { loader: "forge", modName, modVersion, mcVersion };
      } catch (e) {
        // Corrupted mcmod.info
      }
    }

    return { loader: "unknown", modName, modVersion, mcVersion };
  }

  private static extractMinecraftVersion(versionConstraint?: string): string {
    if (!versionConstraint) return "";
    // Extract version number from constraints like ">=1.21", "~1.20.1", etc.
    const match = versionConstraint.match(/[\d.]+/);
    return match ? match[0] : "";
  }

  private static async analyzeForLoader(
    zip: JSZip, 
    detectedLoader: string, 
    targetLoader: string, 
    targetMcVersion: string
  ): Promise<{ errors: AnalysisError[], solutions: AnalysisSolution[] }> {
    const errors: AnalysisError[] = [];
    const solutions: AnalysisSolution[] = [];

    // If target loader matches detected loader, check for missing files
    if (detectedLoader === targetLoader) {
      return this.validateExistingLoader(zip, targetLoader, targetMcVersion);
    }

    // Need to convert between loaders
    errors.push({
      id: "loader-conversion-needed",
      type: "warning", 
      title: `Convert from ${detectedLoader} to ${targetLoader}`,
      description: `This mod is designed for ${detectedLoader} but you want to convert it to ${targetLoader}`,
      tags: ["conversion", "loader"],
    });

    solutions.push({
      id: "convert-loader",
      errorId: "loader-conversion-needed",
      title: `Convert to ${targetLoader}`,
      description: `Generate ${targetLoader} configuration files for Minecraft ${targetMcVersion}`,
      autoFixable: true,
    });

    return { errors, solutions };
  }

  private static async validateExistingLoader(
    zip: JSZip, 
    loader: string, 
    mcVersion: string
  ): Promise<{ errors: AnalysisError[], solutions: AnalysisSolution[] }> {
    const errors: AnalysisError[] = [];
    const solutions: AnalysisSolution[] = [];

    switch (loader) {
      case "quilt":
        if (!zip.file("quilt.mod.json")) {
          errors.push({
            id: "missing-quilt-mod-json",
            type: "critical",
            title: "Missing quilt.mod.json",
            description: "The mod is missing the required quilt.mod.json configuration file",
            tags: ["configuration", "critical"],
          });
          
          solutions.push({
            id: "create-quilt-mod-json",
            errorId: "missing-quilt-mod-json", 
            title: "Create quilt.mod.json",
            description: "Generate a basic quilt.mod.json configuration file",
            autoFixable: true,
          });
        }
        break;

      case "fabric":
        if (!zip.file("fabric.mod.json")) {
          errors.push({
            id: "missing-fabric-mod-json",
            type: "critical",
            title: "Missing fabric.mod.json", 
            description: "The mod is missing the required fabric.mod.json configuration file",
            tags: ["configuration", "critical"],
          });
          
          solutions.push({
            id: "create-fabric-mod-json",
            errorId: "missing-fabric-mod-json",
            title: "Create fabric.mod.json",
            description: "Generate a basic fabric.mod.json configuration file", 
            autoFixable: true,
          });
        }
        break;

      case "forge":
      case "neoforge":
        if (!zip.file("META-INF/mods.toml")) {
          errors.push({
            id: "missing-mods-toml",
            type: "critical",
            title: "Missing mods.toml",
            description: `The mod is missing the required META-INF/mods.toml configuration file for ${loader}`,
            tags: ["configuration", "critical"],
          });
          
          solutions.push({
            id: "create-mods-toml",
            errorId: "missing-mods-toml",
            title: "Create mods.toml",
            description: `Generate a basic mods.toml configuration file for ${loader}`,
            autoFixable: true,
          });
        }
        break;
    }

    return { errors, solutions };
  }
        // Parse quilt.mod.json
        try {
          const modJsonContent = await quiltModJson.async("text");
          const modJson = JSON.parse(modJsonContent);
          
          modName = modJson.quilt_loader?.id || "";
          modVersion = modJson.quilt_loader?.version || "";
          
          // Check for entrypoint issues
          const entrypoints = modJson.quilt_loader?.entrypoints;
          if (!entrypoints || !entrypoints.main) {
            errors.push({
              id: "missing-main-entrypoint",
              type: "critical",
              title: "Runtime Exception: Entrypoint Failure",
              description: "Could not execute entrypoint stage 'main' due to missing or incorrect entrypoint configuration",
              details: "java.lang.RuntimeException: Could not execute entrypoint stage 'main'",
              tags: ["Main Entrypoint", "Class Loading", "Critical"],
              code: "java.lang.RuntimeException: Could not execute entrypoint stage 'main'\n  at " + (modName || "unknown") + ".MainClass"
            });

            solutions.push({
              id: "fix-main-entrypoint",
              errorId: "missing-main-entrypoint",
              title: "Fix Entrypoint Configuration",
              description: "Update the quilt.mod.json file to properly configure the main entrypoint class path.",
              autoFixable: true,
              code: `// In quilt.mod.json
"entrypoints": {
  "main": [
    "${modName ? modName.replace(/-/g, '_') + '.MainClass' : 'com.example.MainClass'}"
  ]
}`
            });
          }

          // Check dependencies
          const dependencies = modJson.quilt_loader?.depends;
          if (!dependencies || !dependencies.quilted_fabric_api) {
            errors.push({
              id: "missing-dependencies",
              type: "warning",
              title: "Missing Dependencies",
              description: "Required Quilt API modules not found in mod dependencies",
              tags: ["Dependencies", "Quilt API"]
            });

            solutions.push({
              id: "add-dependencies",
              errorId: "missing-dependencies",
              title: "Add Missing Dependencies",
              description: "Include required Quilt API dependencies in your mod configuration.",
              autoFixable: true,
              steps: ["quilted_fabric_api", "qsl"]
            });
          }

        } catch (parseError) {
          errors.push({
            id: "invalid-quilt-mod-json",
            type: "critical",
            title: "Invalid quilt.mod.json",
            description: "The quilt.mod.json file contains invalid JSON syntax",
            tags: ["configuration", "syntax"],
          });
        }
      }

      // Check for common class structure issues
      const javaFiles = Object.keys(zip.files).filter(name => name.endsWith('.class'));
      if (javaFiles.length === 0) {
        errors.push({
          id: "no-class-files",
          type: "critical",
          title: "No Class Files Found",
          description: "The JAR file contains no compiled Java class files",
          tags: ["compilation", "classes"]
        });
      }

    } catch (zipError) {
      errors.push({
        id: "invalid-jar-format",
        type: "critical",
        title: "Invalid JAR Format",
        description: "The uploaded file is not a valid JAR archive",
        tags: ["format", "jar"]
      });
    }

    return {
      modName: modName || "Unknown Mod",
      modVersion: modVersion || "1.0.0",
      mcVersion: "1.21",
      loader,
      errors,
      solutions
    };
  }
}
