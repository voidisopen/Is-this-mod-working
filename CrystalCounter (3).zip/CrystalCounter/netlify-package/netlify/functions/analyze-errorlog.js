// Netlify Function for AI crash report analysis
export async function handler(event, context) {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ message: 'Method not allowed' })
    };
  }

  try {
    const { errorLog, targetMcVersion, targetLoader } = JSON.parse(event.body);

    if (!errorLog || !errorLog.trim()) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'No error log provided' })
      };
    }

    if (errorLog.length > 10000000) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Error log too large. Please limit to 10 million characters.' })
      };
    }

    console.log(`🔍 Starting crash report analysis...`);
    console.log(`📋 Log size: ${errorLog.length} characters for ${targetLoader} ${targetMcVersion}`);

    // AI Analysis using pattern matching and rule-based system
    const analysis = analyzeErrorLog(errorLog, targetMcVersion, targetLoader);

    console.log(`✅ Analysis complete: Found ${analysis.errors.length} issues with ${analysis.solutions.length} targeted solutions`);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: JSON.stringify(analysis)
    };

  } catch (error) {
    console.error('Error in analyze-errorlog:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: error.message || 'Internal server error' })
    };
  }
}

// AI Analysis Engine - Pattern-based error detection
function analyzeErrorLog(errorLog, targetMcVersion, targetLoader) {
  const errorPatterns = [
    {
      pattern: /exception|error|failed|crash|stacktrace|throwable|caused by|at\s+[\w.]+\(/gi,
      type: "critical",
      title: "Runtime Exception Detected",
      description: "A runtime exception or error occurred during execution",
      tags: ["exception", "runtime", "crash"],
      solutions: [
        "Review stack trace for root cause",
        "Check for null pointer exceptions",
        "Verify all dependencies are loaded",
        "Update mod to compatible version"
      ]
    },
    {
      pattern: /nullpointerexception|npe|null pointer|\.java:\d+\)|\.kt:\d+\)/gi,
      type: "critical",
      title: "Null Pointer Exception",
      description: "Code is trying to access a null object reference",
      tags: ["null-pointer", "npe", "crash"],
      solutions: [
        "Add null checks before object access",
        "Initialize objects properly",
        "Use Optional for nullable values",
        "Review object lifecycle management"
      ]
    },
    {
      pattern: /entrypoint.*not.*found|main.*class.*not.*found|no.*main.*manifest|could.*not.*find.*or.*load.*main.*class/gi,
      type: "critical",
      title: "Missing Entrypoint Configuration",
      description: "The mod lacks proper entrypoint configuration required for the selected loader",
      tags: ["entrypoint", "configuration", "main-class"],
      solutions: [
        "Create proper mod configuration file (fabric.mod.json/quilt.mod.json)",
        "Add correct main class to manifest",
        "Configure entrypoint values for the target loader"
      ]
    },
    {
      pattern: /mixin.*failed|mixin.*error|@mixin.*could.*not.*apply|mixin.*transformation.*failed/gi,
      type: "critical",
      title: "Mixin System Failure",
      description: "Critical issues with the Mixin framework preventing mod execution",
      tags: ["mixin", "asm", "bytecode"],
      solutions: [
        "Update mixin mappings for target version",
        "Check mixin configuration syntax",
        "Verify target classes exist in the version",
        "Update mixin dependency versions"
      ]
    },
    {
      pattern: /dependency.*not.*found|missing.*dependency|requires.*mod.*not.*present|unsatisfied.*dependency/gi,
      type: "warning",
      title: "Missing Required Dependencies",
      description: "The mod requires dependencies that are not available",
      tags: ["dependencies", "requirements"],
      solutions: [
        "Install missing mod dependencies",
        "Update dependency version constraints",
        "Make dependencies optional where appropriate",
        "Check loader compatibility"
      ]
    },
    {
      pattern: /version.*mismatch|incompatible.*version|wrong.*version|unsupported.*version|version.*conflict/gi,
      type: "warning",
      title: "Version Compatibility Issues",
      description: "Version conflicts between mod components or Minecraft versions",
      tags: ["version", "compatibility"],
      solutions: [
        "Update mod for target Minecraft version",
        "Adjust version constraints in metadata",
        "Use compatible dependency versions",
        "Implement version-specific code paths"
      ]
    },
    {
      pattern: /classnotfound|noclassdeffounderror|class.*not.*found|could.*not.*find.*class/gi,
      type: "critical",
      title: "Missing Required Classes",
      description: "Essential classes are missing from the classpath",
      tags: ["classpath", "classes", "loading"],
      solutions: [
        "Check mod loading order",
        "Verify all required libraries are present",
        "Update class mappings for target version",
        "Add missing dependencies to classpath"
      ]
    }
  ];

  // Extract crash context and stack traces
  const crashContext = extractCrashContext(errorLog);
  
  // Find root cause by analyzing the stack trace
  const rootCause = findRootCause(errorLog, crashContext);
  
  // Generate targeted solutions based on the specific problem
  const { errors, solutions } = generateTargetedFixes(rootCause, crashContext, targetLoader, targetMcVersion);
  
  // Create comprehensive analysis report
  const aiAnalysis = generateIntelligentReport(errorLog, rootCause, errors, targetMcVersion, targetLoader);

  return { aiAnalysis, errors, solutions };
}

function extractCrashContext(errorLog) {
  const context = {
    exceptions: [],
    stackTraces: [],
    errorMessages: [],
    warnings: [],
    modClasses: [],
    minecraftClasses: [],
    causedBy: []
  };

  const lines = errorLog.split('\n');
  
  lines.forEach((line, index) => {
    const trimmed = line.trim();
    
    // Extract exceptions
    if (trimmed.includes('Exception') || trimmed.includes('Error')) {
      context.exceptions.push({ line: trimmed, lineNumber: index });
    }
    
    // Extract stack trace entries
    if (trimmed.startsWith('at ')) {
      const match = trimmed.match(/at\s+([\w.$]+)\.(\w+)\(([^)]*)\)/);
      if (match) {
        context.stackTraces.push({
          className: match[1],
          methodName: match[2],
          source: match[3],
          fullLine: trimmed,
          lineNumber: index
        });
        
        // Categorize classes
        if (match[1].includes('.mod.') || match[1].includes('example') || !match[1].startsWith('net.minecraft')) {
          context.modClasses.push(match[1]);
        } else {
          context.minecraftClasses.push(match[1]);
        }
      }
    }
    
    // Extract "Caused by" chains
    if (trimmed.startsWith('Caused by:')) {
      context.causedBy.push({ line: trimmed, lineNumber: index });
    }
    
    // Extract warnings and errors
    if (trimmed.includes('WARN') || trimmed.includes('WARNING')) {
      context.warnings.push({ line: trimmed, lineNumber: index });
    }
    
    if (trimmed.includes('ERROR') || trimmed.includes('FATAL')) {
      context.errorMessages.push({ line: trimmed, lineNumber: index });
    }
  });

  return context;
}

function findRootCause(errorLog, context) {
  const rootCause = {
    type: 'unknown',
    description: '',
    evidence: [],
    severity: 'warning',
    specificIssue: '',
    fixStrategy: ''
  };

  // Analyze for null pointer exceptions
  if (errorLog.toLowerCase().includes('nullpointerexception')) {
    rootCause.type = 'null_pointer';
    rootCause.severity = 'critical';
    rootCause.description = 'Null Pointer Exception - code is trying to use an object that is null';
    
    // Find the specific line that caused it
    const npeLines = context.stackTraces.filter(st => 
      context.modClasses.some(modClass => st.className.includes(modClass.split('.').pop()))
    );
    
    if (npeLines.length > 0) {
      rootCause.specificIssue = `Null pointer in ${npeLines[0].className}.${npeLines[0].methodName}()`;
      rootCause.fixStrategy = 'add_null_checks';
    }
  }
  
  // Analyze for mixin failures
  else if (errorLog.toLowerCase().includes('mixin')) {
    rootCause.type = 'mixin_failure';
    rootCause.severity = 'critical';
    rootCause.description = 'Mixin transformation failed - incompatible class modification';
    rootCause.specificIssue = 'Mixin system could not apply class transformations';
    rootCause.fixStrategy = 'fix_mixin_config';
  }
  
  // Analyze for dependency issues
  else if (errorLog.toLowerCase().includes('classnotfound') || errorLog.toLowerCase().includes('noclassdef')) {
    rootCause.type = 'missing_dependency';
    rootCause.severity = 'critical';
    rootCause.description = 'Missing required class or dependency';
    rootCause.specificIssue = 'Required mod or library is not loaded';
    rootCause.fixStrategy = 'add_dependencies';
  }
  
  // Analyze for configuration errors
  else if (context.warnings.length > 0 && errorLog.toLowerCase().includes('deprecated')) {
    rootCause.type = 'deprecated_api';
    rootCause.severity = 'warning';
    rootCause.description = 'Using outdated API methods that may be removed';
    rootCause.specificIssue = 'Code uses deprecated APIs';
    rootCause.fixStrategy = 'update_api_usage';
  }
  
  // Analyze for general crashes
  else if (context.exceptions.length > 0) {
    rootCause.type = 'runtime_crash';
    rootCause.severity = 'critical';
    rootCause.description = 'Unexpected runtime exception during execution';
    rootCause.specificIssue = context.exceptions[0].line;
    rootCause.fixStrategy = 'fix_runtime_error';
  }

  rootCause.evidence = context.stackTraces.slice(0, 3); // Top 3 stack trace entries
  return rootCause;
}

function generateTargetedFixes(rootCause, context, targetLoader, targetMcVersion) {
  const errors = [];
  const solutions = [];

  const errorId = `root-cause-${rootCause.type}`;
  
  // Create main error based on root cause
  errors.push({
    id: errorId,
    type: rootCause.severity,
    title: getRootCauseTitle(rootCause.type),
    description: rootCause.description,
    details: `Root cause analysis: ${rootCause.specificIssue}`,
    tags: [rootCause.type, targetLoader, targetMcVersion, 'root-cause'],
    code: rootCause.evidence.map(e => e.fullLine).join('\n')
  });

  // Generate specific solutions based on the root cause
  const targetedSolutions = getTargetedSolutions(rootCause, targetLoader, targetMcVersion);
  
  targetedSolutions.forEach((solution, index) => {
    solutions.push({
      id: `targeted-fix-${index + 1}`,
      errorId: errorId,
      title: solution.title,
      description: solution.description,
      autoFixable: solution.autoFixable,
      steps: solution.steps
    });
  });

  return { errors, solutions };
}

function getRootCauseTitle(type) {
  const titles = {
    'null_pointer': 'Null Pointer Exception Detected',
    'mixin_failure': 'Mixin System Failure',
    'missing_dependency': 'Missing Required Dependencies',
    'deprecated_api': 'Deprecated API Usage',
    'runtime_crash': 'Runtime Exception',
    'unknown': 'General Error Detected'
  };
  return titles[type] || 'Unknown Issue';
}

function getTargetedSolutions(rootCause, targetLoader, targetMcVersion) {
  const solutions = [];

  switch (rootCause.fixStrategy) {
    case 'add_null_checks':
      solutions.push({
        title: 'Add Null Safety Checks',
        description: `Fix null pointer exception by adding proper null checks in ${rootCause.specificIssue}`,
        autoFixable: true,
        steps: [
          'Add null check before accessing object methods',
          'Initialize objects properly in constructor',
          'Use Optional wrapper for nullable values',
          'Add defensive programming checks'
        ]
      });
      break;

    case 'fix_mixin_config':
      solutions.push({
        title: 'Fix Mixin Configuration',
        description: `Update mixin configuration for ${targetLoader} ${targetMcVersion}`,
        autoFixable: true,
        steps: [
          'Check mixin target class compatibility',
          'Update mixin reference map generation',
          'Verify target method signatures',
          'Add proper mixin dependencies'
        ]
      });
      break;

    case 'add_dependencies':
      solutions.push({
        title: 'Add Missing Dependencies',
        description: `Include required dependencies for ${targetLoader} ${targetMcVersion}`,
        autoFixable: true,
        steps: [
          `Add ${targetLoader === 'quilt' ? 'Quilted Fabric API' : 'Fabric API'} dependency`,
          'Update mod configuration file',
          'Check version compatibility',
          'Add to build.gradle dependencies'
        ]
      });
      break;

    case 'update_api_usage':
      solutions.push({
        title: 'Update Deprecated API Usage',
        description: `Replace deprecated API calls with modern ${targetLoader} ${targetMcVersion} equivalents`,
        autoFixable: true,
        steps: [
          'Replace deprecated method calls',
          'Update import statements',
          'Use latest API documentation',
          'Test with current mod loader version'
        ]
      });
      break;

    case 'fix_runtime_error':
      solutions.push({
        title: 'Fix Runtime Error',
        description: `Resolve runtime exception in ${targetLoader} ${targetMcVersion}`,
        autoFixable: false,
        steps: [
          'Review stack trace for error location',
          'Check object initialization order',
          'Verify mod loading sequence',
          'Add proper error handling'
        ]
      });
      break;

    default:
      solutions.push({
        title: 'General Error Fix',
        description: `Apply general fixes for ${targetLoader} ${targetMcVersion}`,
        autoFixable: false,
        steps: [
          'Review error logs carefully',
          'Check mod compatibility',
          'Update to latest mod loader version',
          'Consult mod documentation'
        ]
      });
  }

  return solutions;
}

function generateIntelligentReport(errorLog, rootCause, errors, targetMcVersion, targetLoader) {
  const reportSections = [];

  // Header
  reportSections.push('# 🔍 Crash Report Analysis');
  reportSections.push('');
  reportSections.push('## Summary');
  reportSections.push(`- **Target Configuration:** ${targetLoader} for Minecraft ${targetMcVersion}`);
  reportSections.push(`- **Log Size:** ${errorLog.length.toLocaleString()} characters analyzed`);
  reportSections.push(`- **Root Cause:** ${rootCause.description}`);
  reportSections.push(`- **Severity:** ${rootCause.severity.toUpperCase()}`);
  reportSections.push(`- **Issues Detected:** ${errors.length} total`);
  reportSections.push('');

  // Root Cause Analysis
  reportSections.push('## 🎯 Root Cause Analysis');
  reportSections.push(`**Primary Issue:** ${rootCause.specificIssue}`);
  reportSections.push('');
  reportSections.push('**Evidence from Stack Trace:**');
  rootCause.evidence.forEach((evidence, index) => {
    reportSections.push(`${index + 1}. \`${evidence.fullLine}\``);
  });
  reportSections.push('');

  // Targeted Fixes
  reportSections.push('## 🛠️ Recommended Fixes');
  reportSections.push(`Based on the root cause analysis, here are the specific steps to fix this issue:`);
  reportSections.push('');

  // Add specific recommendations based on loader
  reportSections.push(`## ${targetLoader.charAt(0).toUpperCase() + targetLoader.slice(1)} ${targetMcVersion} Specific Recommendations`);
  if (targetLoader === 'quilt') {
    reportSections.push('- Use Quilt Standard Libraries (QSL) for enhanced compatibility');
    reportSections.push('- Ensure quilt.mod.json has correct schema version');
    reportSections.push('- Check Quilt-specific entrypoint configurations');
    reportSections.push('- Verify Quilted Fabric API compatibility');
  } else if (targetLoader === 'fabric') {
    reportSections.push(`- Update Fabric API to match ${targetMcVersion}`);
    reportSections.push('- Use fabric.mod.json schema version 1');
    reportSections.push('- Check Fabric Language Kotlin if using Kotlin');
    reportSections.push('- Verify mixin refmap generation');
  }
  reportSections.push('');

  // Next Steps
  reportSections.push('## 📋 Next Steps');
  reportSections.push('1. **Apply Automatic Fixes** - Use the auto-fix feature for supported solutions');
  reportSections.push('2. **Test Incrementally** - Apply one fix at a time and test');
  reportSections.push('3. **Check Dependencies** - Ensure all required mods are compatible');
  reportSections.push('4. **Verify Configuration** - Double-check mod configuration files');
  reportSections.push('');

  reportSections.push('---');
  reportSections.push('*This analysis was generated using intelligent crash report analysis. The AI examined your stack trace, identified the root cause, and provided targeted solutions.*');

  return reportSections.join('\n');
}