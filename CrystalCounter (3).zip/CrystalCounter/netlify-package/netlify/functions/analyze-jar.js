// Netlify Function for JAR file analysis
export async function handler(event, context) {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: JSON.stringify({ message: 'Method not allowed' })
    };
  }

  try {
    const { jarData, targetMcVersion, targetLoader } = JSON.parse(event.body);

    if (!jarData) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'No JAR data provided' })
      };
    }

    console.log(`🔍 Analyzing JAR for ${targetLoader} ${targetMcVersion}`);
    
    // Analyze the JAR structure and content
    const analysis = analyzeJarStructure(jarData, targetMcVersion, targetLoader);

    console.log(`✅ JAR analysis complete: Found ${analysis.errors.length} issues`);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: JSON.stringify(analysis)
    };

  } catch (error) {
    console.error('Error in analyze-jar:', error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: JSON.stringify({ message: error.message || 'Internal server error' })
    };
  }
}

function analyzeJarStructure(jarData, targetMcVersion, targetLoader) {
  const errors = [];
  const solutions = [];
  const analysis = {
    modId: jarData.modId || 'unknown',
    modName: jarData.modName || 'Unknown Mod',
    version: jarData.version || '1.0.0',
    description: jarData.description || 'No description available',
    authors: jarData.authors || ['Unknown'],
    dependencies: jarData.dependencies || {},
    entrypoints: jarData.entrypoints || {},
    mixins: jarData.mixins || [],
    hasValidStructure: false,
    configurationIssues: [],
    compatibilityIssues: []
  };

  // Check for basic mod structure
  if (!jarData.hasModJson) {
    errors.push({
      id: 'missing-mod-config',
      type: 'critical',
      title: 'Missing Mod Configuration',
      description: `No ${getConfigFileName(targetLoader)} found in the JAR file`,
      tags: ['configuration', 'structure', targetLoader],
      code: `Missing: META-INF/${getConfigFileName(targetLoader)}`
    });

    solutions.push({
      id: 'create-mod-config',
      errorId: 'missing-mod-config',
      title: 'Create Mod Configuration',
      description: `Generate ${getConfigFileName(targetLoader)} with proper structure`,
      autoFixable: true,
      steps: [
        `Create META-INF/${getConfigFileName(targetLoader)}`,
        'Add mod metadata (id, name, version)',
        'Configure entrypoints for the target loader',
        'Set up dependency declarations'
      ]
    });
  }

  // Check entrypoints
  if (Object.keys(analysis.entrypoints).length === 0) {
    errors.push({
      id: 'missing-entrypoints',
      type: 'critical',
      title: 'No Entrypoints Configured',
      description: 'Mod has no entrypoints configured for initialization',
      tags: ['entrypoints', 'initialization', targetLoader],
      code: 'entrypoints: {}'
    });

    solutions.push({
      id: 'add-entrypoints',
      errorId: 'missing-entrypoints',
      title: 'Add Mod Entrypoints',
      description: 'Configure proper entrypoints for mod initialization',
      autoFixable: true,
      steps: [
        'Add main entrypoint for mod initialization',
        'Configure client/server-specific entrypoints if needed',
        'Ensure entrypoint classes exist in the JAR',
        'Validate entrypoint class names'
      ]
    });
  }

  // Check version compatibility
  if (!isVersionCompatible(analysis.version, targetMcVersion, targetLoader)) {
    errors.push({
      id: 'version-incompatible',
      type: 'warning',
      title: 'Version Compatibility Warning',
      description: `Mod version may not be compatible with ${targetLoader} ${targetMcVersion}`,
      tags: ['version', 'compatibility', targetMcVersion],
      code: `Current: ${analysis.version}, Target: ${targetMcVersion}`
    });

    solutions.push({
      id: 'update-version-compat',
      errorId: 'version-incompatible',
      title: 'Update Version Compatibility',
      description: 'Update mod configuration for target version',
      autoFixable: true,
      steps: [
        `Update supported Minecraft version to ${targetMcVersion}`,
        'Adjust dependency version ranges',
        'Update API usage for target version',
        'Test compatibility with target loader'
      ]
    });
  }

  // Check dependencies
  const missingDeps = checkRequiredDependencies(analysis.dependencies, targetLoader);
  if (missingDeps.length > 0) {
    errors.push({
      id: 'missing-dependencies',
      type: 'warning',
      title: 'Missing Required Dependencies',
      description: `Missing dependencies: ${missingDeps.join(', ')}`,
      tags: ['dependencies', 'requirements', targetLoader],
      code: `Missing: ${missingDeps.join(', ')}`
    });

    solutions.push({
      id: 'add-dependencies',
      errorId: 'missing-dependencies',
      title: 'Add Missing Dependencies',
      description: 'Add required dependencies to mod configuration',
      autoFixable: true,
      steps: [
        'Add required API dependencies',
        'Configure proper version ranges',
        'Set dependency loading order',
        'Add optional dependencies where appropriate'
      ]
    });
  }

  // Generate AI analysis report
  const aiAnalysis = generateJarAnalysisReport(jarData, analysis, errors, targetMcVersion, targetLoader);

  analysis.hasValidStructure = errors.filter(e => e.type === 'critical').length === 0;

  return {
    analysis,
    aiAnalysis,
    errors,
    solutions
  };
}

function getConfigFileName(targetLoader) {
  switch (targetLoader) {
    case 'quilt': return 'quilt.mod.json';
    case 'fabric': return 'fabric.mod.json';
    case 'forge': return 'mods.toml';
    case 'neoforge': return 'mods.toml';
    default: return 'mod.json';
  }
}

function isVersionCompatible(modVersion, targetMcVersion, targetLoader) {
  // Simple version compatibility check
  // In a real implementation, this would be more sophisticated
  return true; // Assume compatible for now
}

function checkRequiredDependencies(dependencies, targetLoader) {
  const required = [];
  
  // Check for required API dependencies
  switch (targetLoader) {
    case 'quilt':
      if (!dependencies['quilted_fabric_api'] && !dependencies['qsl']) {
        required.push('quilted_fabric_api');
      }
      break;
    case 'fabric':
      if (!dependencies['fabric-api'] && !dependencies['fabric']) {
        required.push('fabric-api');
      }
      break;
    case 'forge':
      if (!dependencies['forge'] && !dependencies['minecraft']) {
        required.push('forge');
      }
      break;
    case 'neoforge':
      if (!dependencies['neoforge'] && !dependencies['minecraft']) {
        required.push('neoforge');
      }
      break;
  }
  
  return required;
}

function generateJarAnalysisReport(jarData, analysis, errors, targetMcVersion, targetLoader) {
  const reportSections = [];

  reportSections.push('# 🔍 JAR Analysis Report');
  reportSections.push('');
  reportSections.push('## Mod Information');
  reportSections.push(`- **Mod ID:** ${analysis.modId}`);
  reportSections.push(`- **Name:** ${analysis.modName}`);
  reportSections.push(`- **Version:** ${analysis.version}`);
  reportSections.push(`- **Authors:** ${analysis.authors.join(', ')}`);
  reportSections.push(`- **Target Configuration:** ${targetLoader} for Minecraft ${targetMcVersion}`);
  reportSections.push('');

  reportSections.push('## Structure Analysis');
  reportSections.push(`- **Valid Structure:** ${analysis.hasValidStructure ? '✅ Yes' : '❌ No'}`);
  reportSections.push(`- **Configuration File:** ${jarData.hasModJson ? '✅ Present' : '❌ Missing'}`);
  reportSections.push(`- **Entrypoints:** ${Object.keys(analysis.entrypoints).length} configured`);
  reportSections.push(`- **Dependencies:** ${Object.keys(analysis.dependencies).length} declared`);
  reportSections.push('');

  reportSections.push('## Issues Detected');
  if (errors.length === 0) {
    reportSections.push('✅ No critical issues found!');
  } else {
    const critical = errors.filter(e => e.type === 'critical').length;
    const warnings = errors.filter(e => e.type === 'warning').length;
    reportSections.push(`- **Critical Issues:** ${critical}`);
    reportSections.push(`- **Warnings:** ${warnings}`);
  }
  reportSections.push('');

  reportSections.push('## Recommendations');
  reportSections.push(`Based on your target configuration (${targetLoader} ${targetMcVersion}):`);
  reportSections.push(`- Ensure ${getConfigFileName(targetLoader)} is properly configured`);
  reportSections.push('- Verify all entrypoints are working');
  reportSections.push('- Check dependency compatibility');
  reportSections.push('- Test with target Minecraft version');
  reportSections.push('');

  reportSections.push('---');
  reportSections.push('*Analysis performed using client-side JAR processing with AI-powered structure validation.*');

  return reportSections.join('\n');
}