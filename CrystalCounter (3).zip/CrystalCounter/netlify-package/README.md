# Enhanced AI Analysis - Netlify Deployment

This is a static HTML version of the Enhanced AI Analysis tool optimized for Netlify deployment.

## Features

✅ **Enhanced AI Analysis**
- Target Mod Loader selection (Quilt, Fabric, Forge, NeoForge)
- Target Minecraft Version selection (1.8-1.21)
- **JAR File Upload & Analysis** with client-side processing using JSZip
- **Crash Report / Error Log Analysis** with AI-powered root cause detection
- Intelligent pattern matching for common Minecraft mod issues
- Targeted solutions specific to your configuration
- Auto-fix generation for detected issues

🚀 **Full Feature Support**
- ✅ JAR file upload and structural analysis
- ✅ Client-side JAR parsing (no server processing needed)
- ✅ Mod configuration detection (fabric.mod.json, quilt.mod.json, mods.toml)
- ✅ Dependency and entrypoint validation
- ✅ Crash report analysis with intelligent root cause detection

## Deployment Instructions

### Option 1: Deploy to Netlify (Recommended)

1. **Prepare your files:**
   ```bash
   # Copy the netlify-package folder contents to your deployment directory
   cp -r netlify-package/* your-site-folder/
   ```

2. **Deploy via Netlify CLI:**
   ```bash
   cd your-site-folder
   npm install -g netlify-cli
   netlify deploy --prod
   ```

3. **Or deploy via Netlify Dashboard:**
   - Zip the contents of `netlify-package/`
   - Upload to Netlify dashboard
   - Deploy

### Option 2: Deploy as Static HTML

If you want to deploy just the HTML file to any static hosting:

1. Use `index.html` as your main page
2. The crash report analysis will work immediately
3. No server-side functionality needed

## File Structure

```
netlify-package/
├── index.html                           # Main application
├── netlify.toml                        # Netlify configuration
├── package.json                        # Dependencies
├── netlify/functions/
│   └── analyze-errorlog.js            # Serverless function for crash analysis
└── README.md                          # This file
```

## How It Works

1. **Target Configuration**: Select your mod loader and Minecraft version
2. **Crash Report Analysis**: Paste your crash report or error log
3. **AI Analysis**: The system analyzes patterns and identifies root causes
4. **Targeted Solutions**: Get specific fixes for your configuration

## Supported Analysis

- ✅ Null pointer exceptions
- ✅ Mixin system failures  
- ✅ Missing dependencies
- ✅ Version compatibility issues
- ✅ Runtime exceptions
- ✅ Configuration errors
- ✅ Class loading issues
- ✅ Deprecated API usage

## Technical Details

- **Frontend**: Pure HTML/CSS/JavaScript
- **Styling**: Tailwind CSS via CDN
- **Icons**: Lucide icons
- **Backend**: Netlify Functions (Node.js)
- **Analysis**: Pattern-based AI engine
- **No external APIs required**

## Support

This tool supports:
- **ALL Minecraft versions** (1.8 through 1.21)
- **ALL major mod loaders** (Quilt, Fabric, Forge, NeoForge)
- **Up to 10 million characters** of crash report analysis

## Live Demo

Once deployed, your Enhanced AI Analysis tool will be available at your Netlify URL with full crash report analysis capabilities.